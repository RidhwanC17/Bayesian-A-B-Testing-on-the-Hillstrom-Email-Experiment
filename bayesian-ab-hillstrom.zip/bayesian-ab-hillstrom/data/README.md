Place the Hillstrom MineThatData CSV here as `hillstrom.csv`.

Source: http://blog.minethatdata.com/2008/03/minethatdata-e-mail-analytics-and-data.html
(or `sklift.datasets.fetch_hillstrom` from scikit-uplift). Expected columns: recency, history_segment, history,
mens, womens, zip_code, newbie, channel, segment, visit, conversion, spend (64,000 rows).
