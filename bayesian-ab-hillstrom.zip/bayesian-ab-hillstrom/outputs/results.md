# Bayesian A/B testing on the Hillstrom email experiment — auto-generated results

- Data: `data/hillstrom.csv`; rows: 64,000; seed: 20260109; posterior draws: 20,000; simulations: 2,000


## A. Data checks

**Sample-ratio mismatch** (chi-square of arm counts vs equal thirds, 2 df)


| arm | count | expected |
|---|---|---|
| control | 21306 | 21333.3 |
| mens | 21307 | 21333.3 |
| womens | 21387 | 21333.3 |

chi2 = 0.203, df = 2, p = 0.904


**Covariate balance** (chi-square test of independence, arm × variable)


| variable | chi2 | df | p | Cramér's V |
|---|---|---|---|---|
| history_segment | 13.153 | 12 | 0.358 | 0.0101 |
| zip_code | 2.872 | 4 | 0.579 | 0.0047 |
| channel | 3.632 | 4 | 0.458 | 0.0053 |
| newbie | 0.137 | 2 | 0.934 | 0.0015 |
| mens | 0.796 | 2 | 0.672 | 0.0035 |
| womens | 0.633 | 2 | 0.729 | 0.0031 |

Rows where (spend > 0) disagrees with (conversion == 1): **0**



## B. Beta-Bernoulli per arm (Beta(1,1) prior)


**visit** — posterior per arm (multi-arm expected loss = E[max_l theta_l − theta_k])


| arm | n | successes | observed rate | post. mean | 95% CrI | P(best) | expected loss |
|---|---|---|---|---|---|---|---|
| control | 21306 | 2262 | 0.10617 | 0.10621 | [0.10211, 0.11037] | 0.0000 | 7.66e-02 |
| mens | 21307 | 3894 | 0.18276 | 0.18278 | [0.17766, 0.18796] | 1.0000 | 0.00e+00 |
| womens | 21387 | 3238 | 0.1514 | 0.15142 | [0.14656, 0.15631] | 0.0000 | 3.14e-02 |

**visit** — lift vs no-email control


| arm | abs. lift (mean) | abs. lift 95% CrI | rel. lift (mean) | rel. lift 95% CrI | P(theta_arm > theta_control) |
|---|---|---|---|---|---|
| mens | 0.07657 | [0.07000, 0.08318] | 0.722 | [0.641, 0.806] | 1.0000 |
| womens | 0.04522 | [0.03888, 0.05155] | 0.426 | [0.356, 0.498] | 1.0000 |


**conversion** — posterior per arm (multi-arm expected loss = E[max_l theta_l − theta_k])


| arm | n | successes | observed rate | post. mean | 95% CrI | P(best) | expected loss |
|---|---|---|---|---|---|---|---|
| control | 21306 | 122 | 0.00573 | 0.00577 | [0.00481, 0.00682] | 0.0000 | 6.80e-03 |
| mens | 21307 | 267 | 0.01253 | 0.01258 | [0.01110, 0.01410] | 0.9999 | 6.84e-09 |
| womens | 21387 | 189 | 0.00884 | 0.00888 | [0.00766, 0.01019] | 0.0001 | 3.69e-03 |

**conversion** — lift vs no-email control


| arm | abs. lift (mean) | abs. lift 95% CrI | rel. lift (mean) | rel. lift 95% CrI | P(theta_arm > theta_control) |
|---|---|---|---|---|---|
| mens | 0.00680 | [0.00500, 0.00862] | 1.196 | [0.768, 1.702] | 1.0000 |
| womens | 0.00311 | [0.00152, 0.00474] | 0.552 | [0.236, 0.937] | 0.9999 |


**Bayes factors** (H0: common theta vs H1: independent thetas, same Beta prior on each). Entries are log10 BF01; **negative favours H1 (an arm difference)**, positive favours H0. Pooled-rate priors use the pooled rate of all three arms (data-informed).


**visit**


| comparison | Beta(1,1) | Jeffreys Beta(0.5,0.5) | Beta(0.1,0.1) | Pooled-rate, strength 50 (data-informed) | Pooled-rate, strength 500 (data-informed) |
|---|---|---|---|---|---|
| control vs mens | -108.85 | -108.82 | -108.40 | -109.51 | -107.64 |
| control vs womens | -40.36 | -40.34 | -39.93 | -41.17 | -40.42 |
| mens vs womens | -14.35 | -14.28 | -13.83 | -15.14 | -15.04 |

**conversion**


| comparison | Beta(1,1) | Jeffreys Beta(0.5,0.5) | Beta(0.1,0.1) | Pooled-rate, strength 50 (data-informed) | Pooled-rate, strength 500 (data-informed) |
|---|---|---|---|---|---|
| control vs mens | -9.46 | -10.02 | -10.07 | -10.89 | -11.19 |
| control vs womens | -0.43 | -1.01 | -1.08 | -1.93 | -2.37 |
| mens vs womens | -0.40 | -0.89 | -0.89 | -1.73 | -2.21 |


**Analytic cross-check** of the Monte Carlo output (Var Beta(a,b) = ab/((a+b)^2(a+b+1)); normal approximation to P(theta_arm > theta_control))


| outcome | arm | MC var | analytic var | MC P(>ctrl) | normal-approx P(>ctrl) |
|---|---|---|---|---|---|
| visit | control | 4.441e-06 | 4.455e-06 | — | — |
| visit | mens | 6.965e-06 | 7.010e-06 | 1.0000 | 1.0000 |
| visit | womens | 6.143e-06 | 6.008e-06 | 1.0000 | 1.0000 |
| conversion | control | 2.635e-07 | 2.693e-07 | — | — |
| conversion | mens | 5.914e-07 | 5.828e-07 | 1.0000 | 1.0000 |
| conversion | womens | 4.133e-07 | 4.116e-07 | 0.9999 | 0.9999 |

![posteriors_per_arm.png](figures/posteriors_per_arm.png)

![lift_posteriors.png](figures/lift_posteriors.png)


## C. Prior sensitivity

Priors: Beta(1,1); Jeffreys Beta(0.5,0.5); a pooled-rate prior of strength 50 (**data-informed**: centred on the pooled rate of the subsample / full data). Subsampling: n customers per arm drawn without replacement, 100 replicates per n, plus the full data. Subsampling is exact via the hypergeometric distribution of the success count.



**visit** — posterior-mean lift and P(arm > control), mean and sd across replicates


| n per arm | prior | arm | lift mean | lift sd | P(>ctrl) mean | P(>ctrl) sd |
|---|---|---|---|---|---|---|
| 250 | Beta(1,1) | mens | 0.07663 | 0.02993 | 0.964 | 0.087 |
| 250 | Beta(1,1) | womens | 0.04837 | 0.03117 | 0.867 | 0.171 |
| 250 | Jeffreys Beta(0.5,0.5) | mens | 0.07693 | 0.03005 | 0.963 | 0.088 |
| 250 | Jeffreys Beta(0.5,0.5) | womens | 0.04857 | 0.03129 | 0.867 | 0.171 |
| 250 | Pooled-rate, strength 50 (data-informed) | mens | 0.06437 | 0.02514 | 0.956 | 0.089 |
| 250 | Pooled-rate, strength 50 (data-informed) | womens | 0.04063 | 0.02618 | 0.856 | 0.168 |
| 1000 | Beta(1,1) | mens | 0.07701 | 0.01374 | 1.000 | 0.002 |
| 1000 | Beta(1,1) | womens | 0.04750 | 0.01436 | 0.988 | 0.029 |
| 1000 | Jeffreys Beta(0.5,0.5) | mens | 0.07708 | 0.01375 | 1.000 | 0.002 |
| 1000 | Jeffreys Beta(0.5,0.5) | womens | 0.04754 | 0.01438 | 0.989 | 0.028 |
| 1000 | Pooled-rate, strength 50 (data-informed) | mens | 0.07349 | 0.01311 | 1.000 | 0.002 |
| 1000 | Pooled-rate, strength 50 (data-informed) | womens | 0.04532 | 0.01371 | 0.988 | 0.029 |
| 5000 | Beta(1,1) | mens | 0.07692 | 0.00569 | 1.000 | 0.000 |
| 5000 | Beta(1,1) | womens | 0.04676 | 0.00482 | 1.000 | 0.000 |
| 5000 | Jeffreys Beta(0.5,0.5) | mens | 0.07693 | 0.00569 | 1.000 | 0.000 |
| 5000 | Jeffreys Beta(0.5,0.5) | womens | 0.04677 | 0.00482 | 1.000 | 0.000 |
| 5000 | Pooled-rate, strength 50 (data-informed) | mens | 0.07619 | 0.00563 | 1.000 | 0.000 |
| 5000 | Pooled-rate, strength 50 (data-informed) | womens | 0.04631 | 0.00478 | 1.000 | 0.000 |
| full | Beta(1,1) | mens | 0.07658 | — | 1.000 | — |
| full | Beta(1,1) | womens | 0.04523 | — | 1.000 | — |
| full | Jeffreys Beta(0.5,0.5) | mens | 0.07659 | — | 1.000 | — |
| full | Jeffreys Beta(0.5,0.5) | womens | 0.04523 | — | 1.000 | — |
| full | Pooled-rate, strength 50 (data-informed) | mens | 0.07641 | — | 1.000 | — |
| full | Pooled-rate, strength 50 (data-informed) | womens | 0.04513 | — | 1.000 | — |


**conversion** — posterior-mean lift and P(arm > control), mean and sd across replicates


| n per arm | prior | arm | lift mean | lift sd | P(>ctrl) mean | P(>ctrl) sd |
|---|---|---|---|---|---|---|
| 250 | Beta(1,1) | mens | 0.00683 | 0.00748 | 0.718 | 0.222 |
| 250 | Beta(1,1) | womens | 0.00337 | 0.00764 | 0.621 | 0.265 |
| 250 | Jeffreys Beta(0.5,0.5) | mens | 0.00685 | 0.00751 | 0.734 | 0.235 |
| 250 | Jeffreys Beta(0.5,0.5) | womens | 0.00339 | 0.00767 | 0.631 | 0.288 |
| 250 | Pooled-rate, strength 50 (data-informed) | mens | 0.00573 | 0.00629 | 0.739 | 0.240 |
| 250 | Pooled-rate, strength 50 (data-informed) | womens | 0.00283 | 0.00642 | 0.637 | 0.295 |
| 1000 | Beta(1,1) | mens | 0.00623 | 0.00398 | 0.858 | 0.166 |
| 1000 | Beta(1,1) | womens | 0.00297 | 0.00352 | 0.709 | 0.236 |
| 1000 | Jeffreys Beta(0.5,0.5) | mens | 0.00623 | 0.00398 | 0.861 | 0.166 |
| 1000 | Jeffreys Beta(0.5,0.5) | womens | 0.00298 | 0.00352 | 0.710 | 0.241 |
| 1000 | Pooled-rate, strength 50 (data-informed) | mens | 0.00594 | 0.00380 | 0.863 | 0.167 |
| 1000 | Pooled-rate, strength 50 (data-informed) | womens | 0.00284 | 0.00336 | 0.711 | 0.242 |
| 5000 | Beta(1,1) | mens | 0.00672 | 0.00167 | 0.997 | 0.009 |
| 5000 | Beta(1,1) | womens | 0.00300 | 0.00164 | 0.905 | 0.135 |
| 5000 | Jeffreys Beta(0.5,0.5) | mens | 0.00672 | 0.00167 | 0.997 | 0.009 |
| 5000 | Jeffreys Beta(0.5,0.5) | womens | 0.00300 | 0.00164 | 0.906 | 0.136 |
| 5000 | Pooled-rate, strength 50 (data-informed) | mens | 0.00665 | 0.00166 | 0.997 | 0.009 |
| 5000 | Pooled-rate, strength 50 (data-informed) | womens | 0.00297 | 0.00162 | 0.906 | 0.136 |
| full | Beta(1,1) | mens | 0.00680 | — | 1.000 | — |
| full | Beta(1,1) | womens | 0.00311 | — | 1.000 | — |
| full | Jeffreys Beta(0.5,0.5) | mens | 0.00680 | — | 1.000 | — |
| full | Jeffreys Beta(0.5,0.5) | womens | 0.00311 | — | 1.000 | — |
| full | Pooled-rate, strength 50 (data-informed) | mens | 0.00679 | — | 1.000 | — |
| full | Pooled-rate, strength 50 (data-informed) | womens | 0.00310 | — | 1.000 | — |


**Note.** Conversion is rare: the arms have only control = 122, mens = 267, womens = 189 conversions, so the prior can matter. At n = 250 per arm the strength-50 pooled prior shrinks the mean conversion lift by 16% (mens) and 16% (womens) relative to Beta(1,1), versus 16% / 16% for visits. On the full data the three priors' conversion lifts differ by at most 0.00002 (absolute), i.e. the likelihood dominates once all ~21,000 customers per arm are used.


![prior_sensitivity.png](figures/prior_sensitivity.png)


## D. Calibration check (coverage of 95% equal-tailed credible intervals)

theta drawn from the prior, s ~ Binomial(n, theta); 20,000 simulations per row. Expected coverage ≈ 0.95 when the generating prior equals the fitting prior. The last rows deliberately use a *mismatched* generating prior as a contrast.


| fit prior | generating prior | case | n | coverage | MC s.e. | mean CrI width |
|---|---|---|---|---|---|---|
| Beta(1,1) | Beta(1,1) | matched | 250 | 0.9516 | 0.0015 | 0.09701 |
| Beta(1,1) | Beta(1,1) | matched | 1000 | 0.9515 | 0.0015 | 0.04856 |
| Beta(1,1) | Beta(1,1) | matched | 5000 | 0.9527 | 0.0015 | 0.02175 |
| Beta(1,1) | Beta(1,1) | matched | 21000 | 0.9532 | 0.0015 | 0.01065 |
| Jeffreys Beta(0.5,0.5) | Jeffreys Beta(0.5,0.5) | matched | 250 | 0.9484 | 0.0016 | 0.07878 |
| Jeffreys Beta(0.5,0.5) | Jeffreys Beta(0.5,0.5) | matched | 1000 | 0.9494 | 0.0016 | 0.03967 |
| Jeffreys Beta(0.5,0.5) | Jeffreys Beta(0.5,0.5) | matched | 5000 | 0.9517 | 0.0015 | 0.01764 |
| Jeffreys Beta(0.5,0.5) | Jeffreys Beta(0.5,0.5) | matched | 21000 | 0.9517 | 0.0015 | 0.00861 |
| Pooled-rate, strength 50 (data-informed) | Pooled-rate, strength 50 (data-informed) | matched | 250 | 0.9514 | 0.0015 | 0.01733 |
| Pooled-rate, strength 50 (data-informed) | Pooled-rate, strength 50 (data-informed) | matched | 1000 | 0.9487 | 0.0016 | 0.00899 |
| Pooled-rate, strength 50 (data-informed) | Pooled-rate, strength 50 (data-informed) | matched | 5000 | 0.9507 | 0.0015 | 0.00408 |
| Pooled-rate, strength 50 (data-informed) | Pooled-rate, strength 50 (data-informed) | matched | 21000 | 0.9500 | 0.0015 | 0.00199 |
| Pooled-rate, strength 50 (data-informed) | Beta(1,1) | MISMATCHED (true prior Beta(1,1)) | 250 | 0.3079 | 0.0033 | 0.09483 |
| Pooled-rate, strength 50 (data-informed) | Beta(1,1) | MISMATCHED (true prior Beta(1,1)) | 1000 | 0.5617 | 0.0035 | 0.04901 |
| Pooled-rate, strength 50 (data-informed) | Beta(1,1) | MISMATCHED (true prior Beta(1,1)) | 5000 | 0.7897 | 0.0029 | 0.02183 |
| Pooled-rate, strength 50 (data-informed) | Beta(1,1) | MISMATCHED (true prior Beta(1,1)) | 21000 | 0.8968 | 0.0022 | 0.01067 |


## E. Revenue per customer: hurdle model

Hurdle indicator c_i = 1[spend > 0]; positive amounts: log y ~ Normal(mu, sigma^2). Priors: theta ~ Beta(1,1); NIG with m0 = 4.3952 (pooled mean log spend among positive spenders), k0 = 1, a0 = 2, b0 = 0.7028 (= pooled variance of log spend × (a0 − 1)). These hyperparameters are data-centred (weakly informative) by design.


Posterior of expected revenue per customer = theta · exp(mu + sigma²/2)


| arm | customers | spenders (spend>0) | observed mean spend $ | post. mean $ | 95% CrI | P(best) | expected loss $ |
|---|---|---|---|---|---|---|---|
| control | 21306 | 122 | 0.653 | 0.653 | [0.511, 0.824] | 0.0000 | 0.7457 |
| mens | 21307 | 267 | 1.423 | 1.397 | [1.175, 1.643] | 0.9691 | 0.0020 |
| womens | 21387 | 189 | 1.077 | 1.091 | [0.893, 1.327] | 0.0309 | 0.3078 |


Incremental revenue per customer vs control


| arm | incremental $/customer (mean) | 95% CrI | P(incremental > 0) |
|---|---|---|---|
| mens | 0.7437 | [0.4612, 1.0294] | 1.0000 |
| womens | 0.4379 | [0.1737, 0.7128] | 0.9994 |


Posterior hyperparameters (kn, mn, an, bn) and closed-form posterior means vs Monte Carlo


| arm | kn | mn | an | bn | E[mu] closed form | E[mu] MC | E[sigma²] bn/(an−1) | E[sigma²] MC |
|---|---|---|---|---|---|---|---|---|
| control | 123.0 | 4.4129 | 63.00 | 38.7699 | 4.4129 | 4.4134 | 0.6253 | 0.6248 |
| mens | 268.0 | 4.3400 | 135.50 | 99.0804 | 4.3400 | 4.3399 | 0.7367 | 0.7367 |
| womens | 190.0 | 4.4616 | 96.50 | 66.1674 | 4.4616 | 4.4614 | 0.6929 | 0.6936 |


**Posterior predictive check on positive spend** (Bayesian p = P(T_rep ≥ T_obs); values near 0 or 1 signal misfit; the last row per arm is the model-implied share of amounts above the observed cap)


| arm | statistic | observed | replicated mean | replicated 95% range | Bayesian p |
|---|---|---|---|---|---|
| control | mean | 114.003 | 113.606 | [90.09, 145.24] | 0.443 |
| control | p90 | 226.882 | 226.390 | [170.02, 309.96] | 0.443 |
| control | max | 499.000 | 694.522 | [347.58, 1518.89] | 0.732 |
| control | share > 499 | 0.000 | 0.012 | — | — |
| mens | mean | 113.527 | 111.090 | [93.94, 132.95] | 0.367 |
| mens | p90 | 262.790 | 230.105 | [183.56, 290.83] | 0.112 |
| mens | max | 499.000 | 923.879 | [496.48, 1878.71] | 0.973 |
| mens | share > 499 | 0.000 | 0.015 | — | — |
| womens | mean | 121.895 | 122.818 | [101.22, 148.54] | 0.514 |
| womens | p90 | 268.038 | 251.095 | [193.79, 320.22] | 0.276 |
| womens | max | 499.000 | 888.741 | [445.01, 1879.44] | 0.946 |
| womens | share > 499 | 0.000 | 0.018 | — | — |

Observed spenders at exactly the maximum amount ($499): control 2 of 122, mens 6 of 267, womens 4 of 189 — mass piled at the cap that a lognormal cannot reproduce.


![revenue_per_customer.png](figures/revenue_per_customer.png)

![posterior_predictive.png](figures/posterior_predictive.png)


## F. Hierarchical model across history_segment (conversion)

Custom random-walk Metropolis-Hastings on (logit mu, log kappa); symmetric Gaussian proposal, step size and scale adapted during burn-in only; 4 chains from over-dispersed starts, 4000 iterations, 1000 burn-in. theta_g is then drawn exactly from its Beta conditional. Hyperpriors: logit(mu) ~ N(logit(pooled rate), 2²), log(kappa) ~ N(log 100, 1.5²).


**Sampler diagnostics**


| arm | parameter | post. mean | post. sd | split R-hat | classic R-hat | ESS (of 12000) | acceptance (4 chains) |
|---|---|---|---|---|---|---|---|
| control | logit_mu | -4.952 | 0.244 | 1.004 | 1.001 | 1282 | 0.34, 0.29, 0.23, 0.27 |
| control | log_kappa | 6.390 | 0.813 | 1.004 | 1.003 | 1267 |  |
| mens | logit_mu | -4.126 | 0.201 | 1.004 | 1.001 | 1230 | 0.23, 0.29, 0.30, 0.28 |
| mens | log_kappa | 5.853 | 0.727 | 1.003 | 1.000 | 1210 |  |
| womens | logit_mu | -4.448 | 0.228 | 1.004 | 1.001 | 1167 | 0.30, 0.38, 0.29, 0.36 |
| womens | log_kappa | 5.982 | 0.811 | 1.002 | 1.002 | 1151 |  |


**Conversions / customers per segment and arm**


| segment | control s/n | mens s/n | womens s/n |
|---|---|---|---|
| 1) $0 - $100 | 32/7612 | 71/7724 | 61/7634 |
| 2) $100 - $200 | 20/4836 | 42/4691 | 37/4727 |
| 3) $200 - $350 | 28/4044 | 63/4090 | 26/4155 |
| 4) $350 - $500 | 24/2124 | 42/2097 | 20/2188 |
| 5) $500 - $750 | 9/1652 | 22/1597 | 26/1662 |
| 6) $750 - $1,000 | 3/622 | 16/644 | 8/593 |
| 7) $1,000 + | 6/416 | 11/464 | 11/428 |


**Segment-level conversion lift: no pooling vs partial pooling** (segment-level effects are exploratory)


| comparison | segment | no pooling: lift | no pooling: 95% CrI | partial pooling: lift | partial pooling: 95% CrI | CrI width ratio (pp/np) |
|---|---|---|---|---|---|---|
| mens − control | 1) $0 - $100 | 0.00498 | [0.00240, 0.00762] | 0.00506 | [0.00252, 0.00772] | 1.00 |
| mens − control | 2) $100 - $200 | 0.00483 | [0.00156, 0.00828] | 0.00502 | [0.00184, 0.00841] | 0.98 |
| mens − control | 3) $200 - $350 | 0.00848 | [0.00390, 0.01324] | 0.00851 | [0.00435, 0.01292] | 0.92 |
| mens − control | 4) $350 - $500 | 0.00871 | [0.00118, 0.01640] | 0.00910 | [0.00233, 0.01612] | 0.91 |
| mens − control | 5) $500 - $750 | 0.00829 | [0.00163, 0.01541] | 0.00829 | [0.00230, 0.01473] | 0.90 |
| mens − control | 6) $750 - $1,000 | 0.01991 | [0.00672, 0.03470] | 0.01553 | [0.00577, 0.02719] | 0.77 |
| mens − control | 7) $1,000 + | 0.00907 | [-0.00963, 0.02861] | 0.01003 | [-0.00257, 0.02348] | 0.68 |
| womens − control | 1) $0 - $100 | 0.00379 | [0.00128, 0.00633] | 0.00372 | [0.00134, 0.00619] | 0.96 |
| womens − control | 2) $100 - $200 | 0.00370 | [0.00062, 0.00688] | 0.00365 | [0.00065, 0.00677] | 0.98 |
| womens − control | 3) $200 - $350 | -0.00066 | [-0.00425, 0.00296] | -0.00010 | [-0.00357, 0.00330] | 0.95 |
| womens − control | 4) $350 - $500 | -0.00222 | [-0.00857, 0.00377] | -0.00070 | [-0.00640, 0.00475] | 0.90 |
| womens − control | 5) $500 - $750 | 0.01020 | [0.00327, 0.01768] | 0.00881 | [0.00279, 0.01537] | 0.87 |
| womens − control | 6) $750 - $1,000 | 0.00864 | [-0.00236, 0.02106] | 0.00667 | [-0.00122, 0.01599] | 0.73 |
| womens − control | 7) $1,000 + | 0.01117 | [-0.00819, 0.03164] | 0.00858 | [-0.00435, 0.02322] | 0.69 |

![hierarchical_forest.png](figures/hierarchical_forest.png)

![trace_plot.png](figures/trace_plot.png)


## G. Frequentist baseline vs Bayesian (same data)

| outcome | comparison | observed diff | freq. 95% CI (Wald) | z-test p | Bayes post. mean diff | Bayes 95% CrI | P(arm > control) |
|---|---|---|---|---|---|---|---|
| visit | mens − control | 0.07659 | [0.06995, 0.08323] | <1e-16 | 0.07657 | [0.07000, 0.08318] | 1.0000 |
| visit | womens − control | 0.04523 | [0.03889, 0.05157] | <1e-16 | 0.04522 | [0.03888, 0.05155] | 1.0000 |
| conversion | mens − control | 0.00681 | [0.00500, 0.00861] | 1.52e-13 | 0.00680 | [0.00500, 0.00862] | 1.0000 |
| conversion | womens − control | 0.00311 | [0.00150, 0.00472] | 0.000157 | 0.00311 | [0.00152, 0.00474] | 0.9999 |
| spend ($/customer) | mens − control | 0.7698 | Welch [0.4851, 1.0545]; bootstrap [0.4829, 1.0702] | Welch p = 1.16e-07 | 0.7437 | [0.4612, 1.0294] | 1.0000 |
| spend ($/customer) | womens − control | 0.4244 | Welch [0.1690, 0.6799]; bootstrap [0.1685, 0.6677] | Welch p = 0.00113 | 0.4379 | [0.1737, 0.7128] | 0.9994 |


Spend: Welch t-test and a percentile bootstrap (2,000 resamples) for the raw mean difference; the Bayesian row is the hurdle-model incremental expected revenue (a model-based estimand, so it need not equal the raw difference in means).



## H. A/A peeking simulation

True rate 0.01 in both arms, 2000 customers per arm per batch, 10 looks, 2,000 simulations; Beta(1,1) priors; expected-loss threshold epsilon = 0.0003. Monte Carlo s.e. of a rate near 0.05 is about 0.0049.


| rule | flagged at final look only | flagged at any look |
|---|---|---|
| 1. naive two-sided z-test at 0.05, every look | 0.0390 | 0.1885 |
| 2. posterior P(B>A) > 0.95 or < 0.05 | 0.0875 | 0.3355 |
| 3. expected loss < epsilon (stopping) | 0.8265 | 0.9955 |


Rule 3 mean stopping look among simulations that stopped: 2.67 (over all simulations, counting non-stoppers as look 10: 2.70). In an A/A test the true regret of any decision is exactly 0, so for rule 3 'flagged' means 'would stop and decide', which is not a false-positive in the frequentist sense.


**Supplementary A/B scenario (true rates 0.010 vs 0.012)** — regret of the expected-loss rule, 1,000 simulations: stops in 0.998 of runs, mean stopping look 2.25, ships B in 0.876 of runs, mean realised regret 2.48e-04 per customer.


**Honest finding.** Bayesian posterior-probability stopping is not automatically immune to peeking in frequentist error terms: the P(B>A) > 0.95 or < 0.05 rule has two 5% tails, so even at a single look it flags roughly 10% of A/A runs, and repeated looks inflate that much further (see table). The expected-loss rule (3) controls *regret* — the expected cost of a wrong decision — not the false-positive rate, and should not be described as controlling Type I error.


![peeking_bar.png](figures/peeking_bar.png)


## Run info

Runtime by section (s): A data checks: 0.1, B beta-bernoulli: 0.5, C prior sensitivity: 1.8, D calibration: 0.6, E hurdle: 1.3, F hierarchical: 1.2, G frequentist: 0.6, H peeking: 5.3. Total: 11.5s.
