"""Self-checks. Run:  python tests/test_core.py   (or pytest). Uses only numpy/scipy/pandas."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from scipy import integrate, stats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from bayes_ab import conjugate as cj, hierarchical as hm, hurdle as hu, sequential as sq  # noqa: E402
from bayes_ab.data import map_arm, make_synthetic, data_checks  # noqa: E402


def test_map_arm_order():
    assert map_arm("Womens E-Mail") == "womens"
    assert map_arm("Mens E-Mail") == "mens"
    assert map_arm("No E-Mail") == "control"


def test_beta_posterior_and_variance():
    rng = np.random.default_rng(1)
    th = cj.sample_posterior([30, 50], [1000, 1000], cj.UNIFORM, 200000, rng)
    a, b = cj.posterior_params([30, 50], [1000, 1000], cj.UNIFORM)
    assert np.allclose(th.mean(0), a / (a + b), rtol=2e-3)
    assert np.allclose(th.var(0), cj.beta_var(a, b), rtol=3e-2)
    p_mc = (th[:, 1] > th[:, 0]).mean()
    assert abs(p_mc - cj.normal_approx_p_greater(a[1], b[1], a[0], b[0])) < 5e-3


def test_p_best_and_loss_consistency():
    th = np.random.default_rng(2).beta([5, 8, 6], [50, 50, 50], size=(50000, 3))
    t = cj.arm_table(th, ["x", "y", "z"])
    assert abs(t.p_best.sum() - 1) < 1e-12
    assert (t.exp_loss >= 0).all()


def test_bayes_factor_matches_numerical_integration():
    s1, n1, s2, n2, a, b = 12, 100, 25, 120, 1.0, 1.0
    f = lambda t, s, n: stats.beta.pdf(t, a, b) * t ** s * (1 - t) ** (n - s)
    m = lambda s, n: integrate.quad(f, 0, 1, args=(s, n), epsabs=0, epsrel=1e-12, limit=200)[0]
    log_bf = np.log(m(s1 + s2, n1 + n2)) - np.log(m(s1, n1)) - np.log(m(s2, n2))
    assert abs(log_bf - cj.log_bf01(s1, n1, s2, n2, a, b)) < 1e-6


def test_nig_posterior_against_grid():
    y = np.log(np.random.default_rng(3).lognormal(4, .7, 15))
    pr = hu.NIGPrior(m0=3.5, k0=1.0, a0=2.0, b0=0.5)
    post = hu.nig_posterior(y, pr)
    mu = np.linspace(post.mn - 6, post.mn + 6, 601)
    s2 = np.exp(np.linspace(np.log(1e-3), np.log(50), 800))
    M, S = np.meshgrid(mu, s2, indexing="ij")
    n = len(y)
    sq_err = ((y[None, None, :] - M[..., None]) ** 2).sum(-1)
    logp = (-0.5 * np.log(S) - 0.5 * pr.k0 * (M - pr.m0) ** 2 / S - (pr.a0 + 1) * np.log(S) - pr.b0 / S
            - 0.5 * n * np.log(S) - sq_err / (2 * S))
    w = np.exp(logp - logp.max()) * S          # log-spaced s2 grid -> Jacobian S
    w /= w.sum()
    assert abs((w * M).sum() - post.mn) < 1e-3
    assert abs((w * S).sum() - post.bn / (post.an - 1)) < 5e-3 * post.bn / (post.an - 1)


def test_nig_sampler_moments():
    post = hu.NIGPosterior(kn=21.0, mn=4.1, an=12.0, bn=6.0)
    mu, s2 = hu.sample_nig(post, 400000, np.random.default_rng(4))
    assert abs(mu.mean() - 4.1) < 5e-3
    assert abs(s2.mean() - 6.0 / 11.0) < 3e-3


def test_mh_recovers_hyperparameters():
    rng = np.random.default_rng(5)
    mu, kappa, G = 0.02, 80.0, 40
    n = np.full(G, 4000)
    theta = rng.beta(mu * kappa, (1 - mu) * kappa, G)
    s = rng.binomial(n, theta)
    fit = hm.fit_hierarchical(s, n, rng, chains=4, iters=4000, burn=1000)
    d = fit["diag"]
    assert (d.rhat_split < 1.05).all()
    m_hat = 1 / (1 + np.exp(-d.post_mean[0]))
    assert abs(m_hat - mu) < 0.006
    assert all(0.1 < a < 0.6 for a in fit["accept"])


def test_ess_iid_close_to_n():
    x = np.random.default_rng(6).standard_normal(5000)
    assert 0.7 * 5000 < hm.ess_single(x) < 1.4 * 5000


def test_calibration_and_peeking_sanity():
    cov = cj.coverage_check(cj.UNIFORM, 500, 20000, np.random.default_rng(7))
    assert abs(cov["coverage"] - 0.95) < 0.01
    r = sq.peeking_simulation(.01, .01, sims=300, rng=np.random.default_rng(8), mc_draws=500)
    assert r["rule1_any"] >= r["rule1_final"]


def test_synthetic_checks_run():
    df = make_synthetic(6000, seed=1)
    c = data_checks(df)
    assert c["mismatch"] == 0 and len(c["balance"]) == 6


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print("ok  ", fn.__name__)
    print(f"{len(fns)} tests passed")
