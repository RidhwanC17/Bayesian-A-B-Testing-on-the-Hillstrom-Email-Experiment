# Bayesian A/B Testing on the Hillstrom Email Experiment

A from-scratch Bayesian A/B testing framework (numpy / pandas / scipy / matplotlib only; no PyMC) applied to Kevin Hillstrom's
MineThatData E-Mail Analytics and Data Mining Challenge dataset: 64,000 customers randomly assigned to a Men's email, a
Women's email, or no email, with visits, conversions and spend tracked for two weeks.

Built as a Semester V *Bayesian Inference* project (Indian Statistical Institute). Every table and figure in `outputs/` is produced by
`run_analysis.py`; nothing is typed in by hand.

## Quick start

```bash
pip install -r requirements.txt
# put the Hillstrom CSV at data/hillstrom.csv  (see data/README.md)
python run_analysis.py --data data/hillstrom.csv
```

Options: `--out outputs` `--draws 20000` `--sims 2000` `--seed 20260109` `--n-boot 2000`.
`--synthetic` runs the identical pipeline on a synthetic dataset with the same schema. **That mode exists only to test the code;
every number it produces is labelled "NOT A RESULT".** The full run takes about 11 seconds on one CPU core.
Self-checks: `python tests/test_core.py` (10 tests: Bayes factor vs numerical integration, Normal-Inverse-Gamma posterior vs a
brute-force grid, MH sampler recovering known hyperparameters, and so on).

## Layout

```
run_analysis.py          CLI: runs sections A-H, writes outputs/results.md and outputs/figures/*.png
bayes_ab/data.py         loading, arm mapping ('womens' tested before 'mens'), synthetic generator, SRM / balance checks
bayes_ab/conjugate.py    Beta-Bernoulli, P(best), expected loss, Bayes factors, subsampling study, calibration
bayes_ab/hurdle.py       hurdle model: Bernoulli x lognormal with Normal-Inverse-Gamma prior, posterior predictive checks
bayes_ab/hierarchical.py custom Metropolis-Hastings, R-hat, ESS (Geyer), partial pooling across history_segment
bayes_ab/frequentist.py  two-proportion z-test, Welch t-test, bootstrap CI
bayes_ab/sequential.py   A/A peeking simulation (naive z, P(B>A), expected loss)
bayes_ab/plots.py        figures
tests/test_core.py       self-checks
```

## What is analysed

| | Analysis |
|---|---|
| A | Sample-ratio-mismatch test, covariate balance, spend/conversion consistency |
| B | Beta-Bernoulli per arm for visit and conversion: posteriors, P(best), expected loss, absolute and relative lift, Bayes factors under five priors |
| C | Prior sensitivity (Beta(1,1), Jeffreys, data-informed pooled-rate prior) with a subsampling experiment (n = 250, 1000, 5000 per arm, 100 replicates, plus full data) |
| D | Calibration: coverage of 95% credible intervals when theta is drawn from the prior |
| E | Revenue per customer: hurdle model, expected revenue, incremental revenue, posterior predictive checks |
| F | Hierarchical conversion model across `history_segment` with a hand-written MH sampler |
| G | Frequentist baseline side by side with the Bayesian quantities |
| H | A/A peeking simulation |

## Derivations

Notation: arm data are `s` successes in `n` trials, `y_i in {0,1}`.

### 1. Beta-Bernoulli posterior

Likelihood: `L(theta) = prod_i theta^{y_i} (1-theta)^{1-y_i} = theta^s (1-theta)^{n-s}`.
Prior: `pi(theta) = theta^{a-1} (1-theta)^{b-1} / B(a,b)`.

Posterior, dropping everything that does not depend on theta:

```
p(theta | y)  ∝  theta^s (1-theta)^{n-s} · theta^{a-1} (1-theta)^{b-1}
              =  theta^{(a+s)-1} (1-theta)^{(b+n-s)-1}
```

This is the kernel of a Beta density, and the normalising constant must therefore be `1/B(a+s, b+n-s)`, so

```
theta | y  ~  Beta(a + s, b + n - s).
```

### 2. Posterior of a difference and P(theta_B > theta_A)

Arms are independent a priori and the data are independent across arms, so the posteriors are independent with densities `f_A, f_B`
and CDFs `F_A, F_B`. Condition on `theta_A = t`:

```
P(theta_B > theta_A) = ∫_0^1 f_A(t) · P(theta_B > t) dt = ∫_0^1 f_A(t) (1 - F_B(t)) dt.
```

Monte Carlo estimate: draw `theta_A^(m) ~ f_A`, `theta_B^(m) ~ f_B` independently for `m = 1..M` and use

```
P_hat = (1/M) Σ_m 1[ theta_B^(m) > theta_A^(m) ],      s.e. = sqrt( P_hat (1 - P_hat) / M ).
```

The same draws give the whole lift posterior: `Delta^(m) = theta_B^(m) - theta_A^(m)` (absolute) and `Delta^(m) / theta_A^(m)` (relative);
credible intervals are the 2.5% and 97.5% sample quantiles.

### 3. Multi-arm P(best) and expected loss

```
P(arm k is best) = P(theta_k > theta_l for all l ≠ k) = ∫ f_k(t) Π_{l≠k} F_l(t) dt
P_hat_k = (1/M) Σ_m 1[ argmax_l theta_l^(m) = k ]                    (and Σ_k P_hat_k = 1)

L_k = E[ max_l theta_l - theta_k ]  =  E[max_l theta_l] - E[theta_k]
L_hat_k = (1/M) Σ_m ( max_l theta_l^(m) - theta_k^(m) )
```

`L_k >= 0` is the expected regret per customer of committing to arm k when the truth is drawn from the posterior; it is zero only if k is
the best arm with probability one.

### 4. Beta-Binomial marginal likelihood and the Bayes factor

For one arm with prior `Beta(a,b)`, the probability of a particular sequence with `s` successes in `n` trials, averaged over the prior, is

```
m(s,n) = ∫_0^1 theta^s (1-theta)^{n-s} · theta^{a-1}(1-theta)^{b-1} / B(a,b) dtheta
       = B(a+s, b+n-s) / B(a,b),            log m(s,n) = log B(a+s, b+n-s) - log B(a,b).
```

H0: both arms share one theta (`Beta(a,b)` prior); H1: independent thetas, each with a `Beta(a,b)` prior. The binomial coefficients
`C(n1,s1) C(n2,s2)` are the same under both hypotheses and cancel, giving

```
BF01 = m(s1+s2, n1+n2) / ( m(s1,n1) · m(s2,n2) )
log BF01 = log m(s1+s2, n1+n2) - log m(s1,n1) - log m(s2,n2).
```

**Prior sensitivity.** A posterior forgets a weak prior as n grows; a Bayes factor does not, because it compares *prior predictive*
probabilities. A more diffuse prior under H1 spreads mass over rates that the data rule out, which penalises H1 (the Occam factor), so
BF01 moves with the prior even when the posterior hardly does. That is why section B reports it under five priors.

### 5. Normal-Inverse-Gamma posterior

Data `x_1..x_n = log y_i` (positive spenders), `x_i | mu, s2 ~ N(mu, s2)`. Prior: `mu | s2 ~ N(m0, s2/k0)`, `s2 ~ InvGamma(a0, b0)`.
Write `S = Σ (x_i - xbar)^2`, so `Σ (x_i - mu)^2 = S + n (xbar - mu)^2`.

```
likelihood ∝ (s2)^{-n/2} exp{ -[ S + n(xbar - mu)^2 ] / (2 s2) }
prior      ∝ (s2)^{-1/2} exp{ -k0 (mu - m0)^2 / (2 s2) } · (s2)^{-(a0+1)} exp{ -b0 / s2 }
```

**Completing the square.** With `kn = k0 + n` and `mn = (k0 m0 + n xbar)/kn`:

```
n(xbar - mu)^2 + k0(mu - m0)^2
  = kn mu^2 - 2 mu (n xbar + k0 m0) + (n xbar^2 + k0 m0^2)
  = kn (mu - mn)^2 - kn mn^2 + n xbar^2 + k0 m0^2.

Remaining constant:
  n xbar^2 + k0 m0^2 - (n xbar + k0 m0)^2 / kn
  = [ (n + k0)(n xbar^2 + k0 m0^2) - (n xbar + k0 m0)^2 ] / kn
  = [ n k0 xbar^2 + n k0 m0^2 - 2 n k0 xbar m0 ] / kn
  = (n k0 / kn) (xbar - m0)^2.
```

Hence the identity `n(xbar - mu)^2 + k0(mu - m0)^2 = kn(mu - mn)^2 + (k0 n / kn)(xbar - m0)^2`.

**Collecting powers of s2.** Multiplying likelihood and prior, the exponent of `s2` is `-n/2 - 1/2 - (a0 + 1)`. Split it as
`-1/2` (belongs to the Normal kernel for mu) and `-(a0 + n/2 + 1)` (the Inverse-Gamma kernel). The exponential term becomes

```
exp{ -[ 2 b0 + S + (k0 n / kn)(xbar - m0)^2 + kn (mu - mn)^2 ] / (2 s2) }
```

so

```
p(mu, s2 | x) ∝ (s2)^{-1/2} exp{ -kn (mu - mn)^2 / (2 s2) }  ·  (s2)^{-(an+1)} exp{ -bn / s2 }

an = a0 + n/2,     bn = b0 + S/2 + k0 n (xbar - m0)^2 / (2 kn),
```

that is `s2 | x ~ InvGamma(an, bn)` and `mu | s2, x ~ N(mn, s2/kn)`. Sampling: `s2 = 1 / Gamma(an, rate = bn)`, then `mu`.
(Checked numerically in `tests/test_core.py` against a brute-force grid posterior.)

### 6. Hurdle factorisation and expected revenue

Let `c_i = 1[spend_i > 0]`, `n1 = Σ c_i`. The likelihood is

```
Π_i theta^{c_i} (1-theta)^{1-c_i}  ×  Π_{i: c_i=1} f(y_i | mu, s2)
= [ theta^{n1} (1-theta)^{n-n1} ] × [ Π_{c_i=1} f(y_i | mu, s2) ].
```

The prior factorises as `pi(theta) · pi(mu, s2)`, so the posterior is a product of a function of theta alone and a function of
(mu, s2) alone: they are **independent a posteriori** and are sampled separately:

```
theta | data ~ Beta(1 + n1, 1 + n - n1),       (mu, s2) | data ~ NIG(kn, mn, an, bn) using only the n1 positive amounts.
```

Expected revenue per customer: `E[Y] = P(Y > 0) · E[Y | Y > 0] = theta · E[e^X]`, `X ~ N(mu, s2)`. The Normal MGF at t = 1 gives
`E[e^X] = exp(mu + s2/2)`, so

```
R(theta, mu, s2) = theta · exp(mu + s2/2),
```

and the posterior of R is obtained by applying this function to each joint draw `(theta^(m), mu^(m), s2^(m))`.

### 7. Hierarchical model: marginal likelihood, conditional, MH ratio

Per arm, segment `g`: `s_g | theta_g ~ Bin(n_g, theta_g)`, `theta_g | mu, kappa ~ Beta(alpha, beta)` with `alpha = mu kappa`, `beta = (1-mu) kappa`.

Integrating out `theta_g`:

```
p(s_g | mu, kappa) = C(n_g, s_g) ∫ theta^{s_g + alpha - 1} (1-theta)^{n_g - s_g + beta - 1} / B(alpha,beta) dtheta
                   = C(n_g, s_g) B(alpha + s_g, beta + n_g - s_g) / B(alpha, beta).
```

Exact conditional (same kernel argument as derivation 1):

```
theta_g | mu, kappa, s_g ~ Beta(mu kappa + s_g, (1-mu) kappa + n_g - s_g).
```

Let `eta = (eta1, eta2) = (logit mu, log kappa)` with priors `eta1 ~ N(logit(pooled rate), 2^2)`, `eta2 ~ N(log 100, 1.5^2)`. Then

```
p(eta | data) ∝ Π_g [ B(alpha + s_g, beta + n_g - s_g) / B(alpha, beta) ] · N(eta1; ·) N(eta2; ·).
```

Proposal: `eta* = eta + e`, `e ~ N(0, Sigma)`, which is symmetric, `q(eta*|eta) = q(eta|eta*)`, so the Hastings ratio reduces to

```
r = p(eta* | data) / p(eta | data),     accept with probability min(1, r).
```

Because the priors are written directly as densities in `eta`, there is **no Jacobian**. (Had they been placed on (mu, kappa), `r` would pick
up `mu*(1-mu*) kappa* / ( mu (1-mu) kappa )`.) The step size and scale are adapted only during burn-in and then frozen, so the retained
draws come from a fixed symmetric kernel.

### 8. Normal-approximation sanity check

`Var[Beta(a,b)] = ab / ((a+b)^2 (a+b+1))`, and for large `a+b` this is about `m(1-m)/(n+3)`, where `m` is the mean. Hand check with the
control visit posterior, `Beta(2263, 19045)`: `m = 0.10621`, `a+b = 21308`, so `Var ≈ 0.10621 × 0.89379 / 21309 = 4.455e-6`, against
4.441e-6 from the Monte Carlo draws in `results.md`. Then `P(theta_B > theta_A) ≈ Φ( (m_B - m_A) / sqrt(Var_A + Var_B) )`. For the
Women's-versus-control conversion comparison: `0.003115 / sqrt(2.693e-7 + 4.116e-7) = 3.77`, `Φ(3.77) ≈ 0.9999`, matching the
Monte Carlo value 0.9999. `results.md` prints this cross-check for every arm.

## Findings

All numbers below come from the run on the real data (`outputs/results.md`, seed 20260109, 20,000 posterior draws).

**Design checks.** The randomisation looks clean: arm counts are 21,306 / 21,307 / 21,387 (control / men's / women's), SRM chi-square
0.203 on 2 df, p = 0.90. Balance tests on history segment, zip code, channel, newbie, mens and womens all have p > 0.35. No row has
`spend > 0` disagreeing with `conversion == 1`.

**Visits.** Visit rate is 10.6% for control (95% CrI 10.2% to 11.0%), 18.3% for the Men's email (17.8% to 18.8%) and 15.1% for the
Women's email (14.7% to 15.6%). Absolute lift versus control is +7.7 percentage points (7.0 to 8.3) for Men's and +4.5 points
(3.9 to 5.2) for Women's; relative lifts are +72% (64% to 81%) and +43% (36% to 50%). The posterior probability that each email beats control is
1.0000 to four decimals, and the Men's email is best with probability 1.0000.

**Conversions.** There are only 122 (control), 267 (men's) and 189 (women's) conversions. Conversion rates are 0.58%, 1.26% and 0.89%.
Absolute lift is +0.68 points (0.50 to 0.86) for Men's, a relative lift of +120% (77% to 170%), and +0.31 points (0.15 to 0.47) for
Women's, +55% (24% to 94%). P(arm > control) is 1.0000 and 0.9999.

**Revenue per customer.** Under the hurdle model, expected revenue is $0.65 for control (0.51 to 0.82), $1.40 for Men's (1.18 to 1.64)
and $1.09 for Women's (0.89 to 1.33). Incremental revenue is +$0.74 per customer for Men's (0.46 to 1.03) and +$0.44 for Women's
(0.17 to 0.71); P(incremental > 0) is 1.0000 and 0.9994, and the Men's email is the best arm for revenue with probability 0.969. The
frequentist Welch difference in mean spend is $0.77 (0.49 to 1.05) for Men's and $0.42 (0.17 to 0.68) for Women's, with bootstrap
intervals of nearly the same width, so the two approaches agree closely.

**Bayes factors depend on the prior even when the posterior does not.** For Women's versus control on conversion, log10 BF01 is -0.43
under Beta(1,1) (BF10 ≈ 2.7, barely worth mentioning), -1.01 under Jeffreys, and -2.37 under a pooled-rate prior of strength 500
(BF10 ≈ 230), while the lift posterior is stable (P(arm > control) = 0.9999). For visits, log10 BF01 lies between -14 and -109 under every prior tried, so the evidence for a difference is overwhelming whichever prior is used.

**Prior sensitivity.** With the full 21,000 or so customers per arm, the three priors' conversion lifts differ by at most 0.00002 in absolute terms.
The prior matters at small n: at 250 customers per arm the strength-50 pooled prior shrinks the mean lift by 16% (the same relative
factor for visits and conversions), and the conversion posterior is mostly noise, with P(Men's > control) averaging 0.72 for conversion
against 0.96 for visits. This is the small-n regime in which the rare conversion outcome is prior-sensitive; it is not the case on the full data.

**Calibration.** With theta drawn from the fitted prior, 95% credible intervals covered 0.948 to 0.953 of the time across priors and sample sizes
(Monte Carlo s.e. about 0.0015). A deliberately mismatched data-informed prior covered only 0.31 to 0.90, which shows what the calibration
guarantee does and does not cover.

**Hierarchical model.** The MH sampler converged (split R-hat at most 1.004, ESS 1151 to 1282 per parameter out of 12,000 draws,
acceptance 0.23 to 0.38 per chain). Pooling is mild because the segments are fairly homogeneous, but it helps most where data are thinnest:
in the two highest-spend segments, credible intervals shrink to 68% to 77% of their no-pooling width, while in the largest segment they
barely change (ratio 1.00 for Men's, 0.96 for Women's). For example, the Men's-versus-control lift in the $750 to $1,000 segment moves from 0.0199 (no pooling)
to 0.0155 (partial pooling). Segment-level differences are exploratory.

**Posterior predictive check.** The lognormal reproduces the mean and 90th percentile of positive spend (Bayesian p between 0.11 and
0.51), but it overpredicts the maximum: the p-values are 0.73, 0.97 and 0.95 for control, Men's and Women's, and the model puts 1.2% to 1.8% of positive
amounts above $499 while none are observed. In total 12 spenders (2, 6 and 4 by arm) sit exactly at $499. The upper tail of the lognormal is therefore too heavy,
so tail-driven quantities such as total revenue at the top end should be taken as approximate.

**Peeking (A/A, true rate 0.01, 10 looks, 2,000 simulations).** The naive z-test flags 3.9% at the final look but 18.9% at any look. The
P(B>A) > 0.95 or < 0.05 rule flags 8.8% at the final look and 33.6% at any look, so Bayesian posterior-probability stopping is not immune to
peeking in frequentist error terms. The expected-loss rule (epsilon = 0.0003) stops in 99.6% of A/A runs, on average at look 2.7. That is the
rule working as designed, because it bounds regret and not the false-positive rate: in a supplementary A/B scenario (0.010 vs 0.012), its mean realised regret was 2.5e-4 per customer.

## Limitations

- Only two weeks of outcomes were recorded, so nothing here speaks to long-term effects, repeat purchase, unsubscribes or fatigue.
- Spend is capped near $499 and piles up at $499, so the lognormal tail is approximate (see the posterior predictive check).
- Segment-level effects are exploratory: seven history segments, many with a handful of conversions, no multiplicity correction.
- Conclusions are causal only because assignment was randomised; the balance and SRM checks support but do not prove that the randomisation was clean.
- Results describe one retailer's customers who had purchased in the last twelve months in 2008.
- The data-informed priors (pooled-rate Beta; the data-centred Normal-Inverse-Gamma hyperparameters) use the data twice, which is why they are labelled as such.
- Bayes factors against a point-null-like "no difference" model are prior-sensitive (see Findings).

## Reproducibility and honesty notes

A single master seed is spawned into independent generators per section, so reruns with the same arguments reproduce `results.md`
exactly. No result is copied from anyone's notebooks. The Hillstrom CSV is not redistributed here; download it from
<http://blog.minethatdata.com/2008/03/minethatdata-e-mail-analytics-and-data.html> (or `fetch_hillstrom` in scikit-uplift) and save it as `data/hillstrom.csv`.
