"""Bayesian A/B testing framework for the Hillstrom MineThatData email experiment."""
__version__ = "1.0.0"
