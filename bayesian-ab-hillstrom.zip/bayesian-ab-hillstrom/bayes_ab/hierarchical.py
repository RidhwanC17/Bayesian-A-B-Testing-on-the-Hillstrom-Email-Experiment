"""Hierarchical (partial-pooling) Beta-Binomial model across segments with a custom
Metropolis-Hastings sampler on (logit mu, log kappa).

s_g | theta_g ~ Bin(n_g, theta_g);  theta_g | mu, kappa ~ Beta(mu*kappa, (1-mu)*kappa)
logit(mu) ~ N(logit(pooled rate), 2^2);  log(kappa) ~ N(log 100, 1.5^2).
theta_g is integrated out for the MH step and then sampled exactly from its conditional.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.special import betaln, expit, logit


@dataclass(frozen=True)
class HierPrior:
    mu_loc: float
    mu_sd: float = 2.0
    lk_loc: float = float(np.log(100.0))
    lk_sd: float = 1.5


def log_marginal(s: np.ndarray, n: np.ndarray, mu: float, kappa: float) -> float:
    """Beta-Binomial marginal log-likelihood (binomial coefficients dropped: constant in (mu, kappa))."""
    a, b = mu * kappa, (1.0 - mu) * kappa
    return float(np.sum(betaln(s + a, n - s + b) - betaln(a, b)))


def log_posterior(x: np.ndarray, s: np.ndarray, n: np.ndarray, prior: HierPrior) -> float:
    """Log posterior of x = (logit mu, log kappa), up to a constant.

    Priors are specified directly on this scale, so no Jacobian term appears.
    """
    lp = (-0.5 * ((x[0] - prior.mu_loc) / prior.mu_sd) ** 2
          - 0.5 * ((x[1] - prior.lk_loc) / prior.lk_sd) ** 2)
    return lp + log_marginal(s, n, float(expit(x[0])), float(np.exp(x[1])))


def run_chain(s, n, prior: HierPrior, x0, iters: int, burn: int, rng: np.random.Generator,
              target: float = 0.3) -> dict:
    """One random-walk MH chain with a symmetric Gaussian proposal.

    The proposal is N(x, (step * sd)^2 I-scaled-by-sd). During burn-in only, `step` is tuned
    toward `target` acceptance every 50 iterations and `sd` (per-coordinate scale) is set from
    the second half of the burn-in history. Both are frozen after burn-in, so the retained
    samples come from a fixed, symmetric kernel.
    """
    z = rng.standard_normal((iters, 2))
    logu = np.log(rng.random(iters))
    x = np.asarray(x0, dtype=float).copy()
    lp = log_posterior(x, s, n, prior)
    chain = np.empty((iters, 2))
    step, sd = 1.0, np.array([0.5, 1.0])
    batch_acc, post_acc = 0, 0
    for t in range(iters):
        prop = x + step * sd * z[t]
        lp_prop = log_posterior(prop, s, n, prior)
        accepted = logu[t] < lp_prop - lp
        if accepted:
            x, lp = prop, lp_prop
        chain[t] = x
        if t < burn:
            batch_acc += accepted
            if (t + 1) % 50 == 0:
                step = float(np.clip(step * np.exp(batch_acc / 50.0 - target), 1e-3, 20.0))
                batch_acc = 0
            if (t + 1) >= 100 and (t + 1) % 100 == 0:
                sd = np.maximum(chain[(t + 1) // 2:t + 1].std(axis=0), 1e-3)
        else:
            post_acc += accepted
    return {"samples": chain[burn:], "accept_rate": post_acc / (iters - burn),
            "step": step, "sd": sd}


def rhat(chains: np.ndarray) -> float:
    """Classic Gelman-Rubin R-hat for an array (m chains, N draws)."""
    m, N = chains.shape
    W = chains.var(axis=1, ddof=1).mean()
    B = N * chains.mean(axis=1).var(ddof=1)
    var_plus = (N - 1) / N * W + B / N
    return float(np.sqrt(var_plus / W))


def split_rhat(chains: np.ndarray) -> float:
    """Split R-hat: each chain is cut in half and the halves are treated as separate chains."""
    m, N = chains.shape
    h = N // 2
    return rhat(np.concatenate([chains[:, :h], chains[:, h:2 * h]], axis=0))


def ess_single(x: np.ndarray) -> float:
    """ESS of one chain via autocorrelation and Geyer's initial positive sequence."""
    n = len(x)
    x = x - x.mean()
    f = np.fft.rfft(x, 2 * n)
    acov = np.fft.irfft(f * np.conj(f))[:n] / n
    if acov[0] <= 0:
        return float(n)
    rho = acov / acov[0]
    m = (n - 1) // 2
    pairs = rho[0:2 * m:2] + rho[1:2 * m + 1:2]        # Gamma_k = rho_{2k} + rho_{2k+1}
    neg = np.where(pairs < 0)[0]
    K = neg[0] if len(neg) else len(pairs)
    tau = -1.0 + 2.0 * pairs[:K].sum()
    return float(n / max(tau, 1.0 / n))


def ess(chains: np.ndarray) -> float:
    """Total ESS across chains (sum of per-chain ESS)."""
    return float(sum(ess_single(c) for c in chains))


def fit_hierarchical(s: np.ndarray, n: np.ndarray, rng: np.random.Generator, chains: int = 4,
                     iters: int = 4000, burn: int = 1000) -> dict:
    """Run `chains` dispersed MH chains; return hyper draws, diagnostics and exact theta draws."""
    s = np.asarray(s, dtype=float); n = np.asarray(n, dtype=float)
    pooled = s.sum() / n.sum()
    prior = HierPrior(mu_loc=float(logit(pooled)))
    starts = [np.array([prior.mu_loc, prior.lk_loc]) + 1.5 * np.array([prior.mu_sd, prior.lk_sd])
              * rng.standard_normal(2) for _ in range(chains)]
    runs = [run_chain(s, n, prior, x0, iters, burn, rng) for x0 in starts]
    arr = np.stack([r["samples"] for r in runs])             # (chains, N, 2)
    names = ["logit_mu", "log_kappa"]
    diag = pd.DataFrame({
        "parameter": names,
        "post_mean": arr.reshape(-1, 2).mean(0),
        "post_sd": arr.reshape(-1, 2).std(0, ddof=1),
        "rhat_split": [split_rhat(arr[:, :, j]) for j in range(2)],
        "rhat_classic": [rhat(arr[:, :, j]) for j in range(2)],
        "ess": [ess(arr[:, :, j]) for j in range(2)],
    })
    flat = arr.reshape(-1, 2)
    mu, kappa = expit(flat[:, 0]), np.exp(flat[:, 1])
    a = mu[:, None] * kappa[:, None] + s[None, :]
    b = (1 - mu)[:, None] * kappa[:, None] + (n - s)[None, :]
    theta_pp = rng.beta(a, b)                                 # exact conditional draws
    return {"chains": arr, "diag": diag, "accept": [r["accept_rate"] for r in runs],
            "steps": [r["step"] for r in runs], "hyper": flat, "theta": theta_pp, "prior": prior}


def no_pooling_draws(s, n, draws: int, rng: np.random.Generator) -> np.ndarray:
    """Independent Beta(1,1) posteriors per segment, shape (draws, G)."""
    s = np.asarray(s, dtype=float); n = np.asarray(n, dtype=float)
    return rng.beta(1 + s, 1 + n - s, size=(draws, len(s)))
