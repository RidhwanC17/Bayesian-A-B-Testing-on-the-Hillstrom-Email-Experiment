"""Data loading, schema normalisation, synthetic generator and design checks."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

#: Arm order used everywhere in the package. Index 0 is the control.
ARMS: tuple[str, ...] = ("control", "mens", "womens")
CONTROL: int = 0
ARM_LABELS = {"control": "No E-Mail (control)", "mens": "Men's E-Mail", "womens": "Women's E-Mail"}

REQUIRED_COLUMNS = [
    "recency", "history_segment", "history", "mens", "womens", "zip_code",
    "newbie", "channel", "segment", "visit", "conversion", "spend",
]
BALANCE_VARS = ["history_segment", "zip_code", "channel", "newbie", "mens", "womens"]


def map_arm(label: str) -> str:
    """Map a raw segment label to 'control' | 'mens' | 'womens'.

    'womens' is tested before 'mens' because 'mens' is a substring of 'womens'.
    """
    t = str(label).strip().lower()
    if "womens" in t:
        return "womens"
    if "mens" in t:
        return "mens"
    if t.startswith("no"):
        return "control"
    raise ValueError(f"Unrecognised treatment label: {label!r}")


def _finalise(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    df["arm"] = df["segment"].map(map_arm)
    for c in ("visit", "conversion"):
        df[c] = df[c].astype(int)
    df["spend"] = df["spend"].astype(float)
    df["paid"] = (df["spend"] > 0).astype(int)  # hurdle indicator c_i = 1[spend > 0]
    if df[["visit", "conversion", "spend", "arm"]].isna().any().any():
        raise ValueError("NaNs in outcome / treatment columns")
    return df


def load_data(path: str) -> pd.DataFrame:
    """Read the Hillstrom CSV, lower-case column names, add `arm` and `paid`."""
    return _finalise(pd.read_csv(path))


def make_synthetic(n: int = 64000, seed: int = 0) -> pd.DataFrame:
    """Synthetic data with the Hillstrom schema. Used ONLY to test the pipeline.

    Every number computed from it is NOT a result about real customers.
    """
    rng = np.random.default_rng(seed)
    seg_levels = ["1) $0 - $100", "2) $100 - $200", "3) $200 - $350", "4) $350 - $500",
                  "5) $500 - $750", "6) $750 - $1,000", "7) $1,000 +"]
    lower = np.array([0, 100, 200, 350, 500, 750, 1000.0])
    width = np.array([100, 100, 150, 150, 250, 250, 500.0])
    g = rng.choice(7, size=n, p=[.32, .25, .17, .11, .08, .04, .03])
    history = lower[g] + rng.random(n) * width[g]
    arm_idx = rng.choice(3, size=n)  # random assignment
    labels = np.array(["No E-Mail", "Mens E-Mail", "Womens E-Mail"])
    p_visit = np.array([0.10, 0.17, 0.15])[arm_idx] * (1 + 0.1 * (g - 2) / 3)
    visit = rng.random(n) < np.clip(p_visit, 0, 1)
    p_conv = np.array([0.05, 0.07, 0.058])[arm_idx]
    conversion = visit & (rng.random(n) < p_conv)
    amount = np.minimum(np.round(np.exp(rng.normal(4.3, 0.8, n)), 2), 499.0)
    df = pd.DataFrame({
        "recency": rng.integers(1, 13, n),
        "history_segment": np.array(seg_levels)[g],
        "history": history,
        "mens": rng.integers(0, 2, n),
        "womens": rng.integers(0, 2, n),
        "zip_code": rng.choice(["Surburban", "Rural", "Urban"], n, p=[.45, .1, .45]),
        "newbie": rng.integers(0, 2, n),
        "channel": rng.choice(["Phone", "Web", "Multichannel"], n, p=[.35, .35, .3]),
        "segment": labels[arm_idx],
        "visit": visit.astype(int),
        "conversion": conversion.astype(int),
        "spend": np.where(conversion, amount, 0.0),
    })
    return _finalise(df)


def arm_counts(df: pd.DataFrame, outcome: str) -> tuple[np.ndarray, np.ndarray]:
    """Return (n_k, s_k) in ARMS order for a binary outcome column."""
    n = df.groupby("arm").size().reindex(ARMS).to_numpy(dtype=np.int64)
    s = df.groupby("arm")[outcome].sum().reindex(ARMS).to_numpy(dtype=np.int64)
    return n, s


def data_checks(df: pd.DataFrame) -> dict:
    """Sample-ratio-mismatch test, covariate balance, spend/conversion consistency."""
    n = df.groupby("arm").size().reindex(ARMS).to_numpy()
    exp = np.full(3, n.sum() / 3)
    chi2 = float(((n - exp) ** 2 / exp).sum())
    srm = {"counts": n, "expected": exp, "chi2": chi2, "df": 2, "p": float(stats.chi2.sf(chi2, 2))}
    rows = []
    for v in BALANCE_VARS:
        tab = pd.crosstab(df["arm"], df[v])
        c2, p, dof, _ = stats.chi2_contingency(tab)
        cramer = float(np.sqrt(c2 / (tab.to_numpy().sum() * (min(tab.shape) - 1))))
        rows.append({"variable": v, "chi2": float(c2), "df": int(dof), "p": float(p), "cramers_v": cramer})
    mismatch = int(((df["spend"] > 0) != (df["conversion"] == 1)).sum())
    return {"srm": srm, "balance": pd.DataFrame(rows), "mismatch": mismatch}
