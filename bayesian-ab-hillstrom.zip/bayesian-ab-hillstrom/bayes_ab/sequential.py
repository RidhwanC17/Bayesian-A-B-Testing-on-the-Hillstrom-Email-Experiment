"""A/A (or A/B) peeking simulation: naive z-test, posterior-probability and expected-loss rules."""
from __future__ import annotations

import numpy as np


def peeking_simulation(p_a: float, p_b: float, batch: int = 2000, looks: int = 10, sims: int = 2000,
                       rng: np.random.Generator | None = None, mc_draws: int = 2000,
                       eps: float = 3e-4, chunk: int = 100) -> dict:
    """Simulate `sims` experiments with `looks` interim analyses of `batch` customers per arm per look.

    Rules (Beta(1,1) priors for the Bayesian ones):
      1. naive two-sided z-test (pooled variance) at 0.05 at every look;
      2. posterior P(B > A) > 0.95 or < 0.05 at any look;
      3. expected loss: stop when min(E[(A-B)+], E[(B-A)+]) < eps, where E[(A-B)+] is the loss of
         shipping B and E[(B-A)+] the loss of keeping A (posterior expectations, Monte Carlo).
    Rule 3 'decides' ship-B if E[(A-B)+] < E[(B-A)+], else keep-A; sims that never stop are
    decided at the final look. Realised regret = true loss of the decision taken.
    """
    rng = rng or np.random.default_rng(0)
    n = batch * np.arange(1, looks + 1)
    ca = rng.binomial(batch, p_a, size=(sims, looks)).cumsum(axis=1)
    cb = rng.binomial(batch, p_b, size=(sims, looks)).cumsum(axis=1)

    pa_hat, pb_hat = ca / n, cb / n
    pool = (ca + cb) / (2 * n)
    var = pool * (1 - pool) * 2 / n
    with np.errstate(divide="ignore", invalid="ignore"):
        z = np.where(var > 0, (pb_hat - pa_hat) / np.sqrt(var), 0.0)
    rule1 = np.abs(z) > 1.959963984540054

    p_b_gt_a = np.empty((sims, looks)); loss_ship = np.empty((sims, looks)); loss_keep = np.empty((sims, looks))
    for i in range(0, sims, chunk):
        sl = slice(i, min(i + chunk, sims)); c = sl.stop - sl.start
        ta = rng.beta((1 + ca[sl])[:, :, None], (1 + n - ca[sl])[:, :, None], size=(c, looks, mc_draws))
        tb = rng.beta((1 + cb[sl])[:, :, None], (1 + n - cb[sl])[:, :, None], size=(c, looks, mc_draws))
        d = tb - ta
        p_b_gt_a[sl] = (d > 0).mean(-1)
        loss_ship[sl] = np.maximum(-d, 0).mean(-1)   # E[(A-B)+]
        loss_keep[sl] = np.maximum(d, 0).mean(-1)    # E[(B-A)+]
    rule2 = (p_b_gt_a > 0.95) | (p_b_gt_a < 0.05)
    rule3 = np.minimum(loss_ship, loss_keep) < eps

    first3 = np.where(rule3.any(1), rule3.argmax(1), looks - 1)
    stopped3 = rule3.any(1)
    idx = np.arange(sims)
    ship_b = loss_ship[idx, first3] < loss_keep[idx, first3]
    true_diff = p_b - p_a
    regret = np.where(ship_b, max(-true_diff, 0.0), max(true_diff, 0.0)) * np.ones(sims)
    se = lambda p: float(np.sqrt(p * (1 - p) / sims))
    out = {
        "p_a": p_a, "p_b": p_b, "batch": batch, "looks": looks, "sims": sims, "eps": eps,
        "rule1_final": float(rule1[:, -1].mean()), "rule1_any": float(rule1.any(1).mean()),
        "rule2_final": float(rule2[:, -1].mean()), "rule2_any": float(rule2.any(1).mean()),
        "rule3_final": float(rule3[:, -1].mean()), "rule3_any": float(stopped3.mean()),
        "rule3_mean_stop_look": float((first3[stopped3] + 1).mean()) if stopped3.any() else float("nan"),
        "rule3_mean_stop_look_all": float((first3 + 1).mean()),
        "rule3_ship_b_rate": float(ship_b.mean()), "rule3_mean_regret": float(regret.mean()),
    }
    for k in ("rule1_final", "rule1_any", "rule2_final", "rule2_any", "rule3_final", "rule3_any"):
        out[k + "_se"] = se(out[k])
    return out
