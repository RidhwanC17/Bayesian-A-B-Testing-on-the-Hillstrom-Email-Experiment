"""Frequentist baselines: two-proportion z-test, Welch t-test, bootstrap CI."""
from __future__ import annotations

import numpy as np
from scipy import stats


def two_prop_ztest(s1: int, n1: int, s2: int, n2: int, level: float = 0.95) -> dict:
    """Difference p1 - p2. z-test uses pooled variance; CI is the unpooled Wald interval."""
    p1, p2 = s1 / n1, s2 / n2
    d = p1 - p2
    pp = (s1 + s2) / (n1 + n2)
    z = d / np.sqrt(pp * (1 - pp) * (1 / n1 + 1 / n2))
    se = np.sqrt(p1 * (1 - p1) / n1 + p2 * (1 - p2) / n2)
    q = stats.norm.ppf(1 - (1 - level) / 2)
    return {"diff": d, "lo": d - q * se, "hi": d + q * se, "z": float(z),
            "p": float(2 * stats.norm.sf(abs(z)))}


def welch_ttest(x1: np.ndarray, x2: np.ndarray, level: float = 0.95) -> dict:
    """Welch t-test on mean(x1) - mean(x2) with Satterthwaite df and matching CI."""
    v1, v2 = x1.var(ddof=1) / len(x1), x2.var(ddof=1) / len(x2)
    d = x1.mean() - x2.mean()
    se = np.sqrt(v1 + v2)
    df = (v1 + v2) ** 2 / (v1 ** 2 / (len(x1) - 1) + v2 ** 2 / (len(x2) - 1))
    t = d / se
    q = stats.t.ppf(1 - (1 - level) / 2, df)
    return {"diff": float(d), "lo": float(d - q * se), "hi": float(d + q * se), "t": float(t),
            "df": float(df), "p": float(2 * stats.t.sf(abs(t), df))}


def bootstrap_means(x: np.ndarray, n_boot: int, rng: np.random.Generator, chunk: int = 100) -> np.ndarray:
    """Bootstrap distribution of the sample mean (resampling rows, vectorised in chunks)."""
    out = np.empty(n_boot)
    for i in range(0, n_boot, chunk):
        m = min(chunk, n_boot - i)
        out[i:i + m] = x[rng.integers(0, len(x), size=(m, len(x)))].mean(axis=1)
    return out


def bootstrap_diff_ci(bm1: np.ndarray, bm2: np.ndarray, level: float = 0.95) -> tuple[float, float]:
    """Percentile CI of mean1 - mean2 from independent bootstrap means of each arm."""
    d = bm1 - bm2
    q = (1 - level) / 2
    return float(np.quantile(d, q)), float(np.quantile(d, 1 - q))
