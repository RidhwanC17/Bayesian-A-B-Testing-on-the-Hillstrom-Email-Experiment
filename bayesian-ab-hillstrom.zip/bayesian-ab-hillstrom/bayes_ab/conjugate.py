"""Beta-Bernoulli analysis: posteriors, P(best), expected loss, Bayes factors,
prior-sensitivity subsampling and a calibration (coverage) check."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.special import betaln
from scipy.stats import beta as beta_dist
from scipy.stats import norm


@dataclass(frozen=True)
class BetaPrior:
    """Beta(a, b) prior. `data_informed` marks priors built from the data."""
    name: str
    a: float
    b: float
    data_informed: bool = False


UNIFORM = BetaPrior("Beta(1,1)", 1.0, 1.0)
JEFFREYS = BetaPrior("Jeffreys Beta(0.5,0.5)", 0.5, 0.5)


def pooled_prior(rate: float, strength: float = 50.0) -> BetaPrior:
    """Beta(rate*strength, (1-rate)*strength): centred on the pooled rate (data-informed)."""
    return BetaPrior(f"Pooled-rate, strength {strength:g} (data-informed)",
                     rate * strength, (1.0 - rate) * strength, True)


def posterior_params(s, n, prior: BetaPrior):
    """Posterior Beta parameters (a + s, b + n - s)."""
    s = np.asarray(s, dtype=float)
    n = np.asarray(n, dtype=float)
    return prior.a + s, prior.b + n - s


def sample_posterior(s, n, prior: BetaPrior, draws: int, rng: np.random.Generator) -> np.ndarray:
    """Independent posterior draws, shape (draws, K)."""
    a, b = posterior_params(s, n, prior)
    return rng.beta(a, b, size=(draws, len(a)))


def _ci(x: np.ndarray, level: float = 0.95, axis: int = 0):
    q = (1 - level) / 2
    return np.quantile(x, q, axis=axis), np.quantile(x, 1 - q, axis=axis)


def arm_table(theta: np.ndarray, arms, level: float = 0.95) -> pd.DataFrame:
    """Posterior mean, CrI, P(best) and multi-arm expected loss E[max_l theta_l - theta_k]."""
    lo, hi = _ci(theta, level)
    best = np.bincount(theta.argmax(axis=1), minlength=theta.shape[1]) / theta.shape[0]
    loss = (theta.max(axis=1, keepdims=True) - theta).mean(axis=0)
    return pd.DataFrame({"arm": list(arms), "mean": theta.mean(0), "lo": lo, "hi": hi,
                         "p_best": best, "exp_loss": loss})


def lift_table(theta: np.ndarray, arms, control: int = 0, level: float = 0.95) -> pd.DataFrame:
    """Absolute and relative lift vs control, with CrIs and P(theta_arm > theta_control)."""
    rows = []
    for k, arm in enumerate(arms):
        if k == control:
            continue
        d = theta[:, k] - theta[:, control]
        r = d / theta[:, control]
        dlo, dhi = _ci(d, level)
        rlo, rhi = _ci(r, level)
        rows.append({"arm": arm, "abs_mean": d.mean(), "abs_lo": dlo, "abs_hi": dhi,
                     "rel_mean": r.mean(), "rel_lo": rlo, "rel_hi": rhi,
                     "p_gt_control": float((d > 0).mean())})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- Bayes factors
def log_marginal(s, n, a: float, b: float):
    """log m(s, n) = log B(a + s, b + n - s) - log B(a, b) (Bernoulli-sequence marginal)."""
    return betaln(a + s, b + n - s) - betaln(a, b)


def log_bf01(s1, n1, s2, n2, a: float, b: float) -> float:
    """log BF01: H0 common theta vs H1 independent thetas, same Beta(a,b) prior on each."""
    return float(log_marginal(s1 + s2, n1 + n2, a, b)
                 - log_marginal(s1, n1, a, b) - log_marginal(s2, n2, a, b))


def bf_table(n, s, arms, priors: list[BetaPrior]) -> pd.DataFrame:
    """log10 BF01 for every arm pair under each prior."""
    rows = []
    for i in range(len(arms)):
        for j in range(i + 1, len(arms)):
            row = {"comparison": f"{arms[i]} vs {arms[j]}"}
            for p in priors:
                row[p.name] = log_bf01(s[i], n[i], s[j], n[j], p.a, p.b) / np.log(10.0)
            rows.append(row)
    return pd.DataFrame(rows)


# --------------------------------------------------------- analytic cross-checks
def beta_var(a, b):
    """Var of Beta(a,b) = ab / ((a+b)^2 (a+b+1))."""
    return a * b / ((a + b) ** 2 * (a + b + 1))


def normal_approx_p_greater(a1, b1, a2, b2) -> float:
    """Normal approximation to P(theta_1 > theta_2) for independent Betas."""
    m = a1 / (a1 + b1) - a2 / (a2 + b2)
    return float(norm.cdf(m / np.sqrt(beta_var(a1, b1) + beta_var(a2, b2))))


# ---------------------------------------------------------- prior sensitivity
def prior_set(pooled_rate) -> list[BetaPrior]:
    """The three priors compared in the sensitivity study."""
    return [UNIFORM, JEFFREYS, pooled_prior(float(pooled_rate), 50.0)]


def subsample_experiment(N, S, sizes=(250, 1000, 5000), reps: int = 100,
                         rng: np.random.Generator | None = None, mc_draws: int = 4000,
                         control: int = 0, arms=("control", "mens", "womens")) -> pd.DataFrame:
    """Subsample n customers per arm (without replacement) `reps` times, plus the full data.

    Because outcomes are binary, the number of successes in a without-replacement subsample of
    size n from an arm with S successes among N is exactly Hypergeometric(S, N - S, n), so we draw
    counts directly. For each replicate and prior, record the posterior-mean lift and
    P(theta_arm > theta_control) (Monte Carlo with `mc_draws`). The pooled-rate prior is rebuilt
    from each replicate's own pooled rate (that is what 'data-informed' means).
    """
    rng = rng or np.random.default_rng(0)
    N = np.asarray(N, dtype=np.int64)
    S = np.asarray(S, dtype=np.int64)
    K = len(N)
    rows = []
    plan = [(int(n), reps) for n in sizes] + [("full", 1)]
    for size, R in plan:
        if size == "full":
            n_k = np.broadcast_to(N, (1, K)).astype(float)
            s_k = np.broadcast_to(S, (1, K)).astype(float)
        else:
            n_k = np.full((R, K), float(size))
            s_k = rng.hypergeometric(S, N - S, size, size=(R, K)).astype(float)
        pooled = s_k.sum(axis=1) / n_k.sum(axis=1)
        for pname in ("uniform", "jeffreys", "pooled"):
            if pname == "uniform":
                a = np.full(R, 1.0); b = np.full(R, 1.0); label = UNIFORM.name
            elif pname == "jeffreys":
                a = np.full(R, .5); b = np.full(R, .5); label = JEFFREYS.name
            else:
                a = pooled * 50.0; b = (1 - pooled) * 50.0; label = pooled_prior(0.01).name
            pa = a[:, None] + s_k
            pb = b[:, None] + n_k - s_k
            means = pa / (pa + pb)
            draws_c = rng.beta(pa[:, control, None], pb[:, control, None], size=(R, mc_draws))
            for k in range(K):
                if k == control:
                    continue
                lift = means[:, k] - means[:, control]
                dk = rng.beta(pa[:, k, None], pb[:, k, None], size=(R, mc_draws))
                pgt = (dk > draws_c).mean(axis=1)
                rows.append({"n_per_arm": (int(N[k]) if size == "full" else size),
                             "size_label": size, "prior": label, "arm": arms[k],
                             "lift_mean": lift.mean(), "lift_sd": lift.std(ddof=1) if R > 1 else np.nan,
                             "p_gt_mean": pgt.mean(), "p_gt_sd": pgt.std(ddof=1) if R > 1 else np.nan,
                             "reps": R})
    return pd.DataFrame(rows)


# --------------------------------------------------------------- calibration
def coverage_check(fit_prior: BetaPrior, n: int, sims: int, rng: np.random.Generator,
                   true_prior: BetaPrior | None = None, level: float = 0.95) -> dict:
    """Coverage of equal-tailed credible intervals.

    theta ~ true_prior (defaults to fit_prior), s ~ Binomial(n, theta), interval from the
    Beta(fit_prior + data) posterior. With true_prior == fit_prior coverage is exactly `level`
    in expectation; with a mismatch it is not (shown as a deliberate contrast).
    """
    tp = true_prior or fit_prior
    theta = rng.beta(tp.a, tp.b, size=sims)
    s = rng.binomial(n, theta)
    q = (1 - level) / 2
    lo = beta_dist.ppf(q, fit_prior.a + s, fit_prior.b + n - s)
    hi = beta_dist.ppf(1 - q, fit_prior.a + s, fit_prior.b + n - s)
    cov = float(((lo <= theta) & (theta <= hi)).mean())
    return {"coverage": cov, "mc_se": float(np.sqrt(cov * (1 - cov) / sims)),
            "mean_width": float((hi - lo).mean())}
