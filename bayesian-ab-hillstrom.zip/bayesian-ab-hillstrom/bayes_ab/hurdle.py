"""Hurdle model for revenue per customer.

c_i = 1[spend_i > 0] ~ Bernoulli(theta);  log y_i | c_i = 1 ~ Normal(mu, sigma^2).
Priors: theta ~ Beta(1,1); mu | s2 ~ N(m0, s2/k0); s2 ~ InvGamma(a0, b0).
Because the prior factorises, theta and (mu, s2) are independent a posteriori.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .conjugate import UNIFORM, BetaPrior


@dataclass(frozen=True)
class NIGPrior:
    """Normal-Inverse-Gamma hyperparameters."""
    m0: float
    k0: float
    a0: float
    b0: float


@dataclass(frozen=True)
class NIGPosterior:
    kn: float
    mn: float
    an: float
    bn: float


def default_nig_prior(pooled_positive_spend: np.ndarray, k0: float = 1.0, a0: float = 2.0) -> NIGPrior:
    """Weakly informative, data-centred: m0 = pooled mean log spend, b0 = pooled var * (a0 - 1).

    This is a data-informed prior (centred using all arms pooled, so it does not favour any arm).
    """
    ly = np.log(np.asarray(pooled_positive_spend, dtype=float))
    return NIGPrior(m0=float(ly.mean()), k0=k0, a0=a0, b0=float(ly.var(ddof=1)) * (a0 - 1.0))


def nig_posterior(log_y: np.ndarray, prior: NIGPrior) -> NIGPosterior:
    """kn = k0 + n, mn = (k0 m0 + n ybar)/kn, an = a0 + n/2,
    bn = b0 + 0.5 sum (y - ybar)^2 + 0.5 k0 n (ybar - m0)^2 / kn."""
    n = len(log_y)
    if n == 0:
        return NIGPosterior(prior.k0, prior.m0, prior.a0, prior.b0)
    ybar = float(np.mean(log_y))
    ss = float(np.sum((log_y - ybar) ** 2))
    kn = prior.k0 + n
    mn = (prior.k0 * prior.m0 + n * ybar) / kn
    an = prior.a0 + n / 2.0
    bn = prior.b0 + 0.5 * ss + 0.5 * prior.k0 * n * (ybar - prior.m0) ** 2 / kn
    return NIGPosterior(kn, mn, an, bn)


def sample_nig(post: NIGPosterior, draws: int, rng: np.random.Generator):
    """sigma^2 ~ InvGamma(an, bn) as 1/Gamma(an, rate bn); mu | sigma^2 ~ N(mn, sigma^2/kn)."""
    s2 = 1.0 / rng.gamma(post.an, 1.0 / post.bn, size=draws)
    mu = rng.normal(post.mn, np.sqrt(s2 / post.kn))
    return mu, s2


@dataclass
class HurdleResult:
    arms: list
    n: np.ndarray
    n_pos: np.ndarray
    theta: np.ndarray       # (draws, K)
    mu: np.ndarray
    sigma2: np.ndarray
    revenue: np.ndarray     # theta * exp(mu + sigma2/2)
    nig_prior: NIGPrior
    nig_post: list


def fit_hurdle(spend_by_arm: list[np.ndarray], arms, draws: int, rng: np.random.Generator,
               theta_prior: BetaPrior = UNIFORM) -> HurdleResult:
    """Posterior of expected revenue per customer for every arm (theta and (mu, s2) sampled separately)."""
    pos = [s[s > 0] for s in spend_by_arm]
    prior = default_nig_prior(np.concatenate(pos))
    K = len(arms)
    n = np.array([len(s) for s in spend_by_arm])
    n_pos = np.array([len(p) for p in pos])
    theta = np.empty((draws, K)); mu = np.empty_like(theta); s2 = np.empty_like(theta)
    posts = []
    for k in range(K):
        theta[:, k] = rng.beta(theta_prior.a + n_pos[k], theta_prior.b + n[k] - n_pos[k], size=draws)
        post = nig_posterior(np.log(pos[k]), prior)
        posts.append(post)
        mu[:, k], s2[:, k] = sample_nig(post, draws, rng)
    return HurdleResult(list(arms), n, n_pos, theta, mu, s2, theta * np.exp(mu + s2 / 2.0), prior, posts)


def posterior_predictive_check(res: HurdleResult, spend_by_arm: list[np.ndarray],
                               rng: np.random.Generator, reps: int = 2000, cap: float | None = None):
    """PPC on positive spend: mean, 90th percentile, maximum, Bayesian p = P(T_rep >= T_obs).

    Each replicate draws (mu, s2) from the posterior and simulates n_pos lognormal amounts.
    Also reports the model-implied share of positive amounts above `cap` (default: observed max).
    Returns (table, replicated_stats dict for plotting).
    """
    pos = [s[s > 0] for s in spend_by_arm]
    if cap is None:
        cap = float(max(p.max() for p in pos))
    reps = min(reps, res.mu.shape[0])
    rows, store = [], {}
    for k, arm in enumerate(res.arms):
        y = pos[k]
        sim = np.exp(res.mu[:reps, k, None]
                     + np.sqrt(res.sigma2[:reps, k, None]) * rng.standard_normal((reps, len(y))))
        stats_rep = {"mean": sim.mean(1), "p90": np.quantile(sim, 0.9, axis=1), "max": sim.max(1)}
        stats_obs = {"mean": y.mean(), "p90": float(np.quantile(y, 0.9)), "max": y.max()}
        store[arm] = (stats_rep, stats_obs)
        for name in ("mean", "p90", "max"):
            rows.append({"arm": arm, "statistic": name, "observed": stats_obs[name],
                         "rep_mean": stats_rep[name].mean(),
                         "rep_lo": np.quantile(stats_rep[name], 0.025),
                         "rep_hi": np.quantile(stats_rep[name], 0.975),
                         "bayes_p": float((stats_rep[name] >= stats_obs[name]).mean())})
        rows.append({"arm": arm, "statistic": f"share > {cap:g}", "observed": float((y > cap).mean()),
                     "rep_mean": float((sim > cap).mean()), "rep_lo": np.nan, "rep_hi": np.nan,
                     "bayes_p": np.nan})
    return pd.DataFrame(rows), store
