"""Matplotlib figures (Agg backend). Every function saves a PNG and returns its path."""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from scipy.stats import beta as beta_dist  # noqa: E402

from .data import ARM_LABELS  # noqa: E402

COL = {"control": "#555555", "mens": "#1f77b4", "womens": "#d62728"}
PCOL = ["#1f77b4", "#ff7f0e", "#2ca02c"]


def _save(fig, path: Path, tag: str = "") -> Path:
    if tag:
        fig.suptitle(tag, color="red", fontsize=10, y=1.0)
    fig.tight_layout()
    fig.savefig(path, dpi=130, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_posteriors(a_b: dict, path: Path, tag: str = "") -> Path:
    """a_b[outcome] = (arms, a_post, b_post). Beta posterior densities per arm."""
    fig, axes = plt.subplots(1, len(a_b), figsize=(6 * len(a_b), 3.8))
    for ax, (outcome, (arms, a, b)) in zip(np.atleast_1d(axes), a_b.items()):
        m = a / (a + b); sd = np.sqrt(a * b / ((a + b) ** 2 * (a + b + 1)))
        x = np.linspace(max(0, (m - 5 * sd).min()), (m + 5 * sd).max(), 600)
        for k, arm in enumerate(arms):
            ax.plot(x, beta_dist.pdf(x, a[k], b[k]), color=COL[arm], label=ARM_LABELS[arm])
            ax.fill_between(x, beta_dist.pdf(x, a[k], b[k]), color=COL[arm], alpha=.15)
        ax.set_title(f"Posterior of {outcome} rate (Beta(1,1) prior)"); ax.set_xlabel("rate"); ax.set_yticks([])
        ax.legend(frameon=False)
    return _save(fig, path, tag)


def plot_lifts(lifts: dict, path: Path, tag: str = "") -> Path:
    """lifts[outcome][arm] = array of absolute-lift draws vs control."""
    fig, axes = plt.subplots(1, len(lifts), figsize=(6 * len(lifts), 3.8))
    for ax, (outcome, d) in zip(np.atleast_1d(axes), lifts.items()):
        for arm, v in d.items():
            ax.hist(v, bins=80, density=True, alpha=.5, color=COL[arm], label=ARM_LABELS[arm])
            lo, hi = np.quantile(v, [.025, .975])
            ax.hlines(0, lo, hi, color=COL[arm], lw=4)
        ax.axvline(0, color="k", ls="--", lw=1)
        ax.set_title(f"Absolute lift in {outcome} rate vs control (95% CrI bars)"); ax.set_yticks([])
        ax.legend(frameon=False)
    return _save(fig, path, tag)


def plot_prior_sensitivity(df, path: Path, tag: str = "") -> Path:
    """df has columns outcome, n_per_arm, prior, arm, lift_mean, lift_sd."""
    outcomes = list(dict.fromkeys(df["outcome"]))
    arms = list(dict.fromkeys(df["arm"]))
    fig, axes = plt.subplots(len(outcomes), len(arms), figsize=(5.5 * len(arms), 3.6 * len(outcomes)),
                             squeeze=False)
    priors = list(dict.fromkeys(df["prior"]))
    for i, o in enumerate(outcomes):
        for j, arm in enumerate(arms):
            ax = axes[i, j]
            for c, p in zip(PCOL, priors):
                d = df[(df.outcome == o) & (df.arm == arm) & (df.prior == p)].sort_values("n_per_arm")
                x, y, sd = d.n_per_arm.to_numpy(), d.lift_mean.to_numpy(), np.nan_to_num(d.lift_sd.to_numpy())
                ax.plot(x, y, "o-", color=c, label=p); ax.fill_between(x, y - sd, y + sd, color=c, alpha=.15)
            ax.set_xscale("log"); ax.set_xlabel("customers per arm (log scale; last point = full data)")
            ax.set_ylabel("posterior-mean lift"); ax.set_title(f"{o}: {ARM_LABELS[arm]} - control (mean ± sd)")
            ax.axhline(0, color="k", lw=.5)
            if i == 0 and j == 0:
                ax.legend(frameon=False, fontsize=7)
    return _save(fig, path, tag)


def plot_revenue(revenue: np.ndarray, arms, path: Path, tag: str = "") -> Path:
    fig, axes = plt.subplots(1, 2, figsize=(12, 3.8))
    hi = np.quantile(revenue, .995)
    for k, arm in enumerate(arms):
        axes[0].hist(revenue[:, k], bins=np.linspace(0, hi, 120), density=True, alpha=.5,
                     color=COL[arm], label=ARM_LABELS[arm])
    axes[0].set_title("Posterior of expected revenue per customer ($)"); axes[0].legend(frameon=False)
    axes[0].set_yticks([])
    for k, arm in enumerate(arms):
        if arm == "control":
            continue
        d = revenue[:, k] - revenue[:, 0]
        axes[1].hist(d, bins=100, density=True, alpha=.5, color=COL[arm], label=ARM_LABELS[arm])
    axes[1].axvline(0, color="k", ls="--", lw=1)
    axes[1].set_title("Incremental revenue per customer vs control ($)"); axes[1].legend(frameon=False)
    axes[1].set_yticks([])
    return _save(fig, path, tag)


def plot_ppc(store: dict, path: Path, tag: str = "") -> Path:
    arms = list(store)
    fig, axes = plt.subplots(len(arms), 3, figsize=(12, 2.9 * len(arms)), squeeze=False)
    for i, arm in enumerate(arms):
        rep, obs = store[arm]
        for j, name in enumerate(("mean", "p90", "max")):
            ax = axes[i, j]; ax.hist(rep[name], bins=60, color=COL[arm], alpha=.6)
            ax.axvline(obs[name], color="k", lw=2)
            p = (rep[name] >= obs[name]).mean()
            ax.set_title(f"{arm}: {name}  (obs {obs[name]:.1f}, p={p:.2f})", fontsize=9); ax.set_yticks([])
    return _save(fig, path, tag)


def plot_forest(seg_labels, results: dict, path: Path, tag: str = "") -> Path:
    """results[comparison] = dict(np=(mean, lo, hi arrays), pp=(...))."""
    fig, axes = plt.subplots(1, len(results), figsize=(6.2 * len(results), 4.2), sharey=True)
    y = np.arange(len(seg_labels))
    for ax, (name, r) in zip(np.atleast_1d(axes), results.items()):
        for off, key, c, lab in ((-.15, "np", "#888888", "No pooling"), (.15, "pp", "#1f77b4", "Partial pooling")):
            m, lo, hi = r[key]
            ax.errorbar(m, y + off, xerr=[m - lo, hi - m], fmt="o", color=c, label=lab, capsize=2, ms=4)
        ax.axvline(0, color="k", ls="--", lw=1)
        ax.set_yticks(y); ax.set_yticklabels([s.replace("$", r"\$") for s in seg_labels]); ax.invert_yaxis()
        ax.set_title(f"{name}: conversion lift by history segment"); ax.set_xlabel("absolute lift (95% CrI)")
    np.atleast_1d(axes)[0].legend(frameon=False, fontsize=8)
    return _save(fig, path, tag)


def plot_trace(fits: dict, path: Path, tag: str = "") -> Path:
    """fits[arm]['chains'] has shape (chains, N, 2)."""
    arms = list(fits)
    fig, axes = plt.subplots(len(arms), 2, figsize=(12, 2.6 * len(arms)), squeeze=False)
    for i, arm in enumerate(arms):
        ch = fits[arm]["chains"]
        for j, name in enumerate(("logit(mu)", "log(kappa)")):
            for c in range(ch.shape[0]):
                axes[i, j].plot(ch[c, :, j], lw=.5, alpha=.8)
            axes[i, j].set_title(f"{arm}: trace of {name} (post burn-in, {ch.shape[0]} chains)", fontsize=9)
    return _save(fig, path, tag)


def plot_peeking(res: dict, path: Path, tag: str = "") -> Path:
    labels = ["Naive z-test", "P(B>A) rule", "Expected-loss rule"]
    final = [res["rule1_final"], res["rule2_final"], res["rule3_final"]]
    anyl = [res["rule1_any"], res["rule2_any"], res["rule3_any"]]
    x = np.arange(3); w = .38
    fig, ax = plt.subplots(figsize=(7.5, 4))
    ax.bar(x - w / 2, final, w, label="final look only", color="#1f77b4")
    ax.bar(x + w / 2, anyl, w, label="at any of the looks", color="#d62728")
    for xi, v in zip(x - w / 2, final): ax.text(xi, v + .005, f"{v:.3f}", ha="center", fontsize=8)
    for xi, v in zip(x + w / 2, anyl): ax.text(xi, v + .005, f"{v:.3f}", ha="center", fontsize=8)
    ax.axhline(.05, color="k", ls="--", lw=1); ax.set_xticks(x); ax.set_xticklabels(labels)
    ax.set_ylabel("share of A/A simulations flagged"); ax.legend(frameon=False)
    ax.set_title("A/A peeking: 'declared a difference' (dashed = 0.05)")
    return _save(fig, path, tag)
