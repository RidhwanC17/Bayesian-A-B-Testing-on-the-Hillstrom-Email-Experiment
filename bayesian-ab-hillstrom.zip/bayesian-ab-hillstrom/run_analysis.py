"""CLI: python run_analysis.py --data data/hillstrom.csv   (or --synthetic to test the pipeline)."""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from bayes_ab import conjugate as cj
from bayes_ab import frequentist as fq
from bayes_ab import hierarchical as hm
from bayes_ab import hurdle as hu
from bayes_ab import plots as pl
from bayes_ab import sequential as sq
from bayes_ab.data import ARMS, CONTROL, arm_counts, data_checks, load_data, make_synthetic

N_SECTIONS = 9


# ------------------------------------------------------------------ formatting
def f(x, d=4):
    return "—" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x:.{d}f}"


def ci(lo, hi, d=4):
    return f"[{f(lo, d)}, {f(hi, d)}]"


def pv(p):
    return "<1e-16" if p < 1e-16 else f"{p:.3g}"


def md_table(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    out = ["| " + " | ".join(map(str, cols)) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for row in df.itertuples(index=False):
        out.append("| " + " | ".join(str(v) for v in row) + " |")
    return "\n".join(out) + "\n"


class Report:
    def __init__(self, tag: str):
        self.tag, self.parts = tag, []

    def h(self, text, level=2):
        self.parts.append(f"\n{'#' * level} {text}{self.tag}\n")

    def p(self, text):
        self.parts.append(text + "\n")

    def t(self, df):
        self.parts.append(md_table(df))

    def img(self, name):
        self.parts.append(f"![{name}](figures/{name})\n")

    def text(self):
        return "\n".join(self.parts)


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data", default="data/hillstrom.csv", help="path to the Hillstrom CSV")
    ap.add_argument("--synthetic", action="store_true", help="use synthetic data (pipeline test ONLY)")
    ap.add_argument("--out", default="outputs", help="output directory")
    ap.add_argument("--draws", type=int, default=20000, help="posterior draws")
    ap.add_argument("--sims", type=int, default=2000, help="simulation replicates (peeking; x10 for calibration)")
    ap.add_argument("--seed", type=int, default=20260109, help="master random seed")
    ap.add_argument("--n-boot", type=int, default=2000, help="bootstrap resamples for the spend CI")
    return ap.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    t_start = time.perf_counter()
    timings: dict[str, float] = {}
    syn = args.synthetic
    tag = " [SYNTHETIC — NOT A RESULT]" if syn else ""
    out = Path(args.out); figs = out / "figures"; figs.mkdir(parents=True, exist_ok=True)

    if syn:
        df = make_synthetic(seed=args.seed); src = "synthetic data (pipeline test only)"
    else:
        if not Path(args.data).exists():
            print(f"ERROR: {args.data} not found. Place the Hillstrom CSV there or use --synthetic.", file=sys.stderr)
            return 2
        df = load_data(args.data); src = str(args.data)

    ss = np.random.SeedSequence(args.seed).spawn(N_SECTIONS)
    rng = {k: np.random.default_rng(s) for k, s in zip("ABCDEFGH", ss)}
    D = args.draws
    R = Report(tag)
    R.parts.append("# Bayesian A/B testing on the Hillstrom email experiment — auto-generated results\n")
    if syn:
        R.parts.append("> **SYNTHETIC DATA — EVERY NUMBER IN THIS FILE IS NOT A RESULT.** "
                       "It only shows that the pipeline runs.\n")
    R.p(f"- Data: `{src}`; rows: {len(df):,}; seed: {args.seed}; posterior draws: {D:,}; simulations: {args.sims:,}")

    def tick(name, t0):
        timings[name] = time.perf_counter() - t0
        print(f"[{name}] {timings[name]:.1f}s", flush=True)

    # ------------------------------------------------------------ A. data checks
    t0 = time.perf_counter()
    chk = data_checks(df)
    srm = chk["srm"]
    R.h("A. Data checks")
    R.p("**Sample-ratio mismatch** (chi-square of arm counts vs equal thirds, 2 df)\n")
    R.t(pd.DataFrame({"arm": ARMS, "count": srm["counts"], "expected": [f"{e:.1f}" for e in srm["expected"]]}))
    R.p(f"chi2 = {srm['chi2']:.3f}, df = 2, p = {pv(srm['p'])}\n")
    R.p("**Covariate balance** (chi-square test of independence, arm × variable)\n")
    bal = chk["balance"].copy()
    R.t(pd.DataFrame({"variable": bal.variable, "chi2": bal.chi2.map(lambda v: f(v, 3)), "df": bal.df,
                      "p": bal.p.map(pv), "Cramér's V": bal.cramers_v.map(lambda v: f(v, 4))}))
    R.p(f"Rows where (spend > 0) disagrees with (conversion == 1): **{chk['mismatch']}**\n")
    tick("A data checks", t0)

    # ------------------------------------------------- B. Beta-Bernoulli per arm
    t0 = time.perf_counter()
    R.h("B. Beta-Bernoulli per arm (Beta(1,1) prior)")
    theta, post_ab, lifts_draws, counts = {}, {}, {}, {}
    for outcome in ("visit", "conversion"):
        n, s = arm_counts(df, outcome)
        counts[outcome] = (n, s)
        th = cj.sample_posterior(s, n, cj.UNIFORM, D, rng["B"]); theta[outcome] = th
        a, b = cj.posterior_params(s, n, cj.UNIFORM); post_ab[outcome] = (list(ARMS), a, b)
        lifts_draws[outcome] = {ARMS[k]: th[:, k] - th[:, CONTROL] for k in range(3) if k != CONTROL}
        at = cj.arm_table(th, ARMS)
        R.p(f"\n**{outcome}** — posterior per arm (multi-arm expected loss = E[max_l theta_l − theta_k])\n")
        R.t(pd.DataFrame({"arm": at.arm, "n": n, "successes": s, "observed rate": (s / n).round(5),
                          "post. mean": at["mean"].map(lambda v: f(v, 5)),
                          "95% CrI": [ci(l, h, 5) for l, h in zip(at.lo, at.hi)],
                          "P(best)": at.p_best.map(lambda v: f(v, 4)),
                          "expected loss": at.exp_loss.map(lambda v: f"{v:.2e}")}))
        lt = cj.lift_table(th, ARMS)
        R.p(f"**{outcome}** — lift vs no-email control\n")
        R.t(pd.DataFrame({"arm": lt.arm,
                          "abs. lift (mean)": lt.abs_mean.map(lambda v: f(v, 5)),
                          "abs. lift 95% CrI": [ci(l, h, 5) for l, h in zip(lt.abs_lo, lt.abs_hi)],
                          "rel. lift (mean)": lt.rel_mean.map(lambda v: f(v, 3)),
                          "rel. lift 95% CrI": [ci(l, h, 3) for l, h in zip(lt.rel_lo, lt.rel_hi)],
                          "P(theta_arm > theta_control)": lt.p_gt_control.map(lambda v: f(v, 4))}))
    # Bayes factors under several priors
    R.p("\n**Bayes factors** (H0: common theta vs H1: independent thetas, same Beta prior on each). "
        "Entries are log10 BF01; **negative favours H1 (an arm difference)**, positive favours H0. "
        "Pooled-rate priors use the pooled rate of all three arms (data-informed).\n")
    for outcome in ("visit", "conversion"):
        n, s = counts[outcome]
        pooled = s.sum() / n.sum()
        pri = [cj.UNIFORM, cj.JEFFREYS, cj.BetaPrior("Beta(0.1,0.1)", .1, .1),
               cj.pooled_prior(pooled, 50), cj.pooled_prior(pooled, 500)]
        bt = cj.bf_table(n, s, ARMS, pri)
        R.p(f"**{outcome}**\n")
        R.t(bt.assign(**{c: bt[c].map(lambda v: f(v, 2)) for c in bt.columns[1:]}))
    # analytic cross-check (derivation 8)
    R.p("\n**Analytic cross-check** of the Monte Carlo output (Var Beta(a,b) = ab/((a+b)^2(a+b+1)); "
        "normal approximation to P(theta_arm > theta_control))\n")
    rows = []
    for outcome in ("visit", "conversion"):
        _, a, b = post_ab[outcome]
        th = theta[outcome]
        for k in range(3):
            row = {"outcome": outcome, "arm": ARMS[k], "MC var": f"{th[:, k].var(ddof=1):.3e}",
                   "analytic var": f"{cj.beta_var(a[k], b[k]):.3e}"}
            if k != CONTROL:
                row["MC P(>ctrl)"] = f(float((th[:, k] > th[:, 0]).mean()), 4)
                row["normal-approx P(>ctrl)"] = f(cj.normal_approx_p_greater(a[k], b[k], a[0], b[0]), 4)
            else:
                row["MC P(>ctrl)"] = row["normal-approx P(>ctrl)"] = "—"
            rows.append(row)
    R.t(pd.DataFrame(rows))
    R.img("posteriors_per_arm.png"); R.img("lift_posteriors.png")
    pl.plot_posteriors(post_ab, figs / "posteriors_per_arm.png", tag.strip())
    pl.plot_lifts(lifts_draws, figs / "lift_posteriors.png", tag.strip())
    tick("B beta-bernoulli", t0)

    # ------------------------------------------------------ C. prior sensitivity
    t0 = time.perf_counter()
    R.h("C. Prior sensitivity")
    R.p("Priors: Beta(1,1); Jeffreys Beta(0.5,0.5); a pooled-rate prior of strength 50 "
        "(**data-informed**: centred on the pooled rate of the subsample / full data). "
        "Subsampling: n customers per arm drawn without replacement, 100 replicates per n, plus the full data. "
        "Subsampling is exact via the hypergeometric distribution of the success count.\n")
    sens_all = []
    for outcome in ("visit", "conversion"):
        n, s = counts[outcome]
        d = cj.subsample_experiment(n, s, rng=rng["C"], mc_draws=min(D, 4000))
        d.insert(0, "outcome", outcome); sens_all.append(d)
    sens = pd.concat(sens_all, ignore_index=True)
    for outcome in ("visit", "conversion"):
        d = sens[sens.outcome == outcome]
        R.p(f"\n**{outcome}** — posterior-mean lift and P(arm > control), mean and sd across replicates\n")
        R.t(pd.DataFrame({"n per arm": d.size_label.map(lambda v: "full" if v == "full" else v), "prior": d.prior,
                          "arm": d.arm, "lift mean": d.lift_mean.map(lambda v: f(v, 5)),
                          "lift sd": d.lift_sd.map(lambda v: f(v, 5)),
                          "P(>ctrl) mean": d.p_gt_mean.map(lambda v: f(v, 3)),
                          "P(>ctrl) sd": d.p_gt_sd.map(lambda v: f(v, 3))}))
    nconv = counts["conversion"][1]
    pooled_name = cj.pooled_prior(0.01).name

    def _shrink(outcome, arm, size):
        d = sens[(sens.outcome == outcome) & (sens.arm == arm) & (sens.size_label == size)].set_index("prior")
        return 1 - d.loc[pooled_name, "lift_mean"] / d.loc["Beta(1,1)", "lift_mean"]

    def _spread(outcome, arm):
        d = sens[(sens.outcome == outcome) & (sens.arm == arm) & (sens.size_label == "full")]
        return float(d.lift_mean.max() - d.lift_mean.min())

    R.p(f"\n**Note.** Conversion is rare: the arms have only "
        f"{', '.join(f'{a} = {int(v)}' for a, v in zip(ARMS, nconv))} conversions, so the prior can matter. "
        f"At n = 250 per arm the strength-50 pooled prior shrinks the mean conversion lift by "
        f"{100 * _shrink('conversion', 'mens', 250):.0f}% (mens) and {100 * _shrink('conversion', 'womens', 250):.0f}% "
        f"(womens) relative to Beta(1,1), versus {100 * _shrink('visit', 'mens', 250):.0f}% / "
        f"{100 * _shrink('visit', 'womens', 250):.0f}% for visits. On the full data the three priors' conversion "
        f"lifts differ by at most {max(_spread('conversion', 'mens'), _spread('conversion', 'womens')):.5f} "
        "(absolute), i.e. the likelihood dominates once all ~21,000 customers per arm are used.\n")
    R.img("prior_sensitivity.png")
    pl.plot_prior_sensitivity(sens, figs / "prior_sensitivity.png", tag.strip())
    tick("C prior sensitivity", t0)

    # ------------------------------------------------------------ D. calibration
    t0 = time.perf_counter()
    R.h("D. Calibration check (coverage of 95% equal-tailed credible intervals)")
    cal_sims = args.sims * 10
    R.p(f"theta drawn from the prior, s ~ Binomial(n, theta); {cal_sims:,} simulations per row. "
        "Expected coverage ≈ 0.95 when the generating prior equals the fitting prior. "
        "The last rows deliberately use a *mismatched* generating prior as a contrast.\n")
    rate = counts["conversion"][1].sum() / counts["conversion"][0].sum()
    pp50 = cj.pooled_prior(rate, 50)
    rows = []
    for fit, true, lab in [(cj.UNIFORM, None, "matched"), (cj.JEFFREYS, None, "matched"),
                           (pp50, None, "matched"), (pp50, cj.UNIFORM, "MISMATCHED (true prior Beta(1,1))")]:
        for n_ in (250, 1000, 5000, 21000):
            r = cj.coverage_check(fit, n_, cal_sims, rng["D"], true)
            rows.append({"fit prior": fit.name, "generating prior": true.name if true else fit.name, "case": lab,
                         "n": n_, "coverage": f(r["coverage"], 4), "MC s.e.": f(r["mc_se"], 4),
                         "mean CrI width": f(r["mean_width"], 5)})
    R.t(pd.DataFrame(rows))
    tick("D calibration", t0)

    # ------------------------------------------------------------ E. hurdle model
    t0 = time.perf_counter()
    R.h("E. Revenue per customer: hurdle model")
    spend_by_arm = [df.loc[df.arm == a, "spend"].to_numpy() for a in ARMS]
    hr = hu.fit_hurdle(spend_by_arm, ARMS, D, rng["E"])
    pr = hr.nig_prior
    R.p("Hurdle indicator c_i = 1[spend > 0]; positive amounts: log y ~ Normal(mu, sigma^2). "
        f"Priors: theta ~ Beta(1,1); NIG with m0 = {pr.m0:.4f} (pooled mean log spend among positive spenders), "
        f"k0 = {pr.k0:g}, a0 = {pr.a0:g}, b0 = {pr.b0:.4f} (= pooled variance of log spend × (a0 − 1)). "
        "These hyperparameters are data-centred (weakly informative) by design.\n")
    at = cj.arm_table(hr.revenue, ARMS)
    obs_mean = [float(x.mean()) for x in spend_by_arm]
    R.p("Posterior of expected revenue per customer = theta · exp(mu + sigma²/2)\n")
    R.t(pd.DataFrame({"arm": ARMS, "customers": hr.n, "spenders (spend>0)": hr.n_pos,
                      "observed mean spend $": [f(v, 3) for v in obs_mean],
                      "post. mean $": at["mean"].map(lambda v: f(v, 3)),
                      "95% CrI": [ci(l, h, 3) for l, h in zip(at.lo, at.hi)],
                      "P(best)": at.p_best.map(lambda v: f(v, 4)),
                      "expected loss $": at.exp_loss.map(lambda v: f(v, 4))}))
    inc_rows, inc = [], {}
    for k in range(3):
        if k == CONTROL:
            continue
        d = hr.revenue[:, k] - hr.revenue[:, CONTROL]; inc[ARMS[k]] = d
        lo, hi = np.quantile(d, [.025, .975])
        inc_rows.append({"arm": ARMS[k], "incremental $/customer (mean)": f(d.mean(), 4),
                         "95% CrI": ci(lo, hi, 4), "P(incremental > 0)": f(float((d > 0).mean()), 4)})
    R.p("\nIncremental revenue per customer vs control\n")
    R.t(pd.DataFrame(inc_rows))
    R.p("\nPosterior hyperparameters (kn, mn, an, bn) and closed-form posterior means vs Monte Carlo\n")
    rows = []
    for k, post in enumerate(hr.nig_post):
        rows.append({"arm": ARMS[k], "kn": f(post.kn, 1), "mn": f(post.mn, 4), "an": f(post.an, 2),
                     "bn": f(post.bn, 4), "E[mu] closed form": f(post.mn, 4),
                     "E[mu] MC": f(float(hr.mu[:, k].mean()), 4),
                     "E[sigma²] bn/(an−1)": f(post.bn / (post.an - 1), 4),
                     "E[sigma²] MC": f(float(hr.sigma2[:, k].mean()), 4)})
    R.t(pd.DataFrame(rows))
    ppc, store = hu.posterior_predictive_check(hr, spend_by_arm, rng["E"], reps=2000)
    R.p("\n**Posterior predictive check on positive spend** (Bayesian p = P(T_rep ≥ T_obs); values near 0 or 1 "
        "signal misfit; the last row per arm is the model-implied share of amounts above the observed cap)\n")
    R.t(pd.DataFrame({"arm": ppc.arm, "statistic": ppc.statistic, "observed": ppc.observed.map(lambda v: f(v, 3)),
                      "replicated mean": ppc.rep_mean.map(lambda v: f(v, 3)),
                      "replicated 95% range": [ci(l, h, 2) if not np.isnan(l) else "—"
                                               for l, h in zip(ppc.rep_lo, ppc.rep_hi)],
                      "Bayesian p": ppc.bayes_p.map(lambda v: f(v, 3))}))
    cap_v = max(float(x[x > 0].max()) for x in spend_by_arm)
    at_cap = [int((x == cap_v).sum()) for x in spend_by_arm]
    R.p(f"Observed spenders at exactly the maximum amount (${cap_v:g}): "
        + ", ".join(f"{a} {c} of {int(m)}" for a, c, m in zip(ARMS, at_cap, hr.n_pos))
        + " — mass piled at the cap that a lognormal cannot reproduce.\n")
    R.img("revenue_per_customer.png"); R.img("posterior_predictive.png")
    pl.plot_revenue(hr.revenue, ARMS, figs / "revenue_per_customer.png", tag.strip())
    pl.plot_ppc(store, figs / "posterior_predictive.png", tag.strip())
    tick("E hurdle", t0)

    # ------------------------------------------------ F. hierarchical (conversion)
    t0 = time.perf_counter()
    R.h("F. Hierarchical model across history_segment (conversion)")
    segs = sorted(df.history_segment.unique())
    gs = df.groupby(["arm", "history_segment"]).agg(n=("conversion", "size"), s=("conversion", "sum"))
    fits, th_pp, th_np, seg_n, seg_s = {}, {}, {}, {}, {}
    for arm in ARMS:
        n_g = gs.loc[arm].reindex(segs)["n"].to_numpy(); s_g = gs.loc[arm].reindex(segs)["s"].to_numpy()
        seg_n[arm], seg_s[arm] = n_g, s_g
        fit = hm.fit_hierarchical(s_g, n_g, rng["F"], chains=4, iters=4000, burn=1000)
        fits[arm] = fit; th_pp[arm] = fit["theta"]
        th_np[arm] = hm.no_pooling_draws(s_g, n_g, fit["theta"].shape[0], rng["F"])
    R.p("Custom random-walk Metropolis-Hastings on (logit mu, log kappa); symmetric Gaussian proposal, "
        "step size and scale adapted during burn-in only; 4 chains from over-dispersed starts, "
        "4000 iterations, 1000 burn-in. theta_g is then drawn exactly from its Beta conditional. "
        "Hyperpriors: logit(mu) ~ N(logit(pooled rate), 2²), log(kappa) ~ N(log 100, 1.5²).\n")
    rows = []
    for arm in ARMS:
        d = fits[arm]["diag"]
        for j in range(2):
            rows.append({"arm": arm, "parameter": d.parameter[j], "post. mean": f(d.post_mean[j], 3),
                         "post. sd": f(d.post_sd[j], 3), "split R-hat": f(d.rhat_split[j], 3),
                         "classic R-hat": f(d.rhat_classic[j], 3), "ESS (of 12000)": f(d.ess[j], 0),
                         "acceptance (4 chains)": ", ".join(f"{a:.2f}" for a in fits[arm]["accept"]) if j == 0 else ""})
    R.p("**Sampler diagnostics**\n"); R.t(pd.DataFrame(rows))
    sn = pd.DataFrame({"segment": segs})
    for arm in ARMS:
        sn[f"{arm} s/n"] = [f"{int(s)}/{int(n)}" for s, n in zip(seg_s[arm], seg_n[arm])]
    R.p("\n**Conversions / customers per segment and arm**\n"); R.t(sn)
    forest, rows = {}, []
    for arm in ("mens", "womens"):
        res = {}
        for key, T in (("np", th_np), ("pp", th_pp)):
            d = T[arm] - T["control"]
            res[key] = (d.mean(0), np.quantile(d, .025, axis=0), np.quantile(d, .975, axis=0))
        forest[f"{arm} − control"] = res
        for g, seg in enumerate(segs):
            w_np = res["np"][2][g] - res["np"][1][g]; w_pp = res["pp"][2][g] - res["pp"][1][g]
            rows.append({"comparison": f"{arm} − control", "segment": seg,
                         "no pooling: lift": f(res["np"][0][g], 5), "no pooling: 95% CrI": ci(res["np"][1][g], res["np"][2][g], 5),
                         "partial pooling: lift": f(res["pp"][0][g], 5),
                         "partial pooling: 95% CrI": ci(res["pp"][1][g], res["pp"][2][g], 5),
                         "CrI width ratio (pp/np)": f(w_pp / w_np, 2)})
    R.p("\n**Segment-level conversion lift: no pooling vs partial pooling** "
        "(segment-level effects are exploratory)\n")
    R.t(pd.DataFrame(rows))
    R.img("hierarchical_forest.png"); R.img("trace_plot.png")
    pl.plot_forest(segs, forest, figs / "hierarchical_forest.png", tag.strip())
    pl.plot_trace(fits, figs / "trace_plot.png", tag.strip())
    tick("F hierarchical", t0)

    # --------------------------------------------------------- G. frequentist
    t0 = time.perf_counter()
    R.h("G. Frequentist baseline vs Bayesian (same data)")
    rows = []
    for outcome in ("visit", "conversion"):
        n, s = counts[outcome]; lt = cj.lift_table(theta[outcome], ARMS).set_index("arm")
        for k in (1, 2):
            z = fq.two_prop_ztest(int(s[k]), int(n[k]), int(s[0]), int(n[0]))
            b = lt.loc[ARMS[k]]
            rows.append({"outcome": outcome, "comparison": f"{ARMS[k]} − control",
                         "observed diff": f(z["diff"], 5), "freq. 95% CI (Wald)": ci(z["lo"], z["hi"], 5),
                         "z-test p": pv(z["p"]), "Bayes post. mean diff": f(b.abs_mean, 5),
                         "Bayes 95% CrI": ci(b.abs_lo, b.abs_hi, 5), "P(arm > control)": f(b.p_gt_control, 4)})
    bm = [fq.bootstrap_means(x, args.n_boot, rng["G"]) for x in spend_by_arm]
    for k in (1, 2):
        w = fq.welch_ttest(spend_by_arm[k], spend_by_arm[0]); bl, bh = fq.bootstrap_diff_ci(bm[k], bm[0])
        d = inc[ARMS[k]]; lo, hi = np.quantile(d, [.025, .975])
        rows.append({"outcome": "spend ($/customer)", "comparison": f"{ARMS[k]} − control",
                     "observed diff": f(w["diff"], 4),
                     "freq. 95% CI (Wald)": f"Welch {ci(w['lo'], w['hi'], 4)}; bootstrap {ci(bl, bh, 4)}",
                     "z-test p": f"Welch p = {pv(w['p'])}", "Bayes post. mean diff": f(d.mean(), 4),
                     "Bayes 95% CrI": ci(lo, hi, 4), "P(arm > control)": f(float((d > 0).mean()), 4)})
    R.t(pd.DataFrame(rows))
    R.p(f"\nSpend: Welch t-test and a percentile bootstrap ({args.n_boot:,} resamples) for the raw mean difference; "
        "the Bayesian row is the hurdle-model incremental expected revenue (a model-based estimand, so it need "
        "not equal the raw difference in means).\n")
    tick("G frequentist", t0)

    # ----------------------------------------------------------- H. peeking
    t0 = time.perf_counter()
    R.h("H. A/A peeking simulation")
    pk = sq.peeking_simulation(0.01, 0.01, batch=2000, looks=10, sims=args.sims, rng=rng["H"],
                               mc_draws=2000, eps=3e-4)
    R.p(f"True rate 0.01 in both arms, 2000 customers per arm per batch, 10 looks, {args.sims:,} simulations; "
        "Beta(1,1) priors; expected-loss threshold epsilon = 0.0003. "
        "Monte Carlo s.e. of a rate near 0.05 is about "
        f"{np.sqrt(.05 * .95 / args.sims):.4f}.\n")
    R.t(pd.DataFrame([
        {"rule": "1. naive two-sided z-test at 0.05, every look", "flagged at final look only": f(pk["rule1_final"], 4),
         "flagged at any look": f(pk["rule1_any"], 4)},
        {"rule": "2. posterior P(B>A) > 0.95 or < 0.05", "flagged at final look only": f(pk["rule2_final"], 4),
         "flagged at any look": f(pk["rule2_any"], 4)},
        {"rule": "3. expected loss < epsilon (stopping)", "flagged at final look only": f(pk["rule3_final"], 4),
         "flagged at any look": f(pk["rule3_any"], 4)}]))
    R.p(f"\nRule 3 mean stopping look among simulations that stopped: {f(pk['rule3_mean_stop_look'], 2)} "
        f"(over all simulations, counting non-stoppers as look 10: {f(pk['rule3_mean_stop_look_all'], 2)}). "
        "In an A/A test the true regret of any decision is exactly 0, so for rule 3 'flagged' means 'would stop and "
        "decide', which is not a false-positive in the frequentist sense.\n")
    pk2 = sq.peeking_simulation(0.010, 0.012, batch=2000, looks=10, sims=max(args.sims // 2, 200),
                                rng=rng["H"], mc_draws=2000, eps=3e-4)
    R.p("**Supplementary A/B scenario (true rates 0.010 vs 0.012)** — regret of the expected-loss rule, "
        f"{pk2['sims']:,} simulations: stops in {f(pk2['rule3_any'], 3)} of runs, mean stopping look "
        f"{f(pk2['rule3_mean_stop_look'], 2)}, ships B in {f(pk2['rule3_ship_b_rate'], 3)} of runs, "
        f"mean realised regret {pk2['rule3_mean_regret']:.2e} per customer.\n")
    R.p("**Honest finding.** Bayesian posterior-probability stopping is not automatically immune to peeking in "
        "frequentist error terms: the P(B>A) > 0.95 or < 0.05 rule has two 5% tails, so even at a single look "
        "it flags roughly 10% of A/A runs, and repeated looks inflate that much further (see table). "
        "The expected-loss rule (3) controls *regret* — the expected cost of a wrong decision — "
        "not the false-positive rate, and should not be described as controlling Type I error.\n")
    R.img("peeking_bar.png")
    pl.plot_peeking(pk, figs / "peeking_bar.png", tag.strip())
    tick("H peeking", t0)

    total = time.perf_counter() - t_start
    R.h("Run info")
    R.p("Runtime by section (s): " + ", ".join(f"{k}: {v:.1f}" for k, v in timings.items()) + f". Total: {total:.1f}s.")
    (out / "results.md").write_text(R.text(), encoding="utf-8")
    print(f"Done in {total:.1f}s -> {out/'results.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
